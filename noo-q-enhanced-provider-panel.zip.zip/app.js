// Enhanced Service Provider Panel - Noo-Q
class ServiceProviderApp {
    constructor() {
        this.currentSection = 'dashboard';
        this.sidebarOpen = false;
        this.charts = {};
        this.notifications = [];
        
        // Load data from the provided JSON
        this.data = {
            currentProvider: {
                id: "prov_001",
                businessName: "Elite Hair Studio",
                ownerName: "Rajesh Kumar",
                email: "rajesh@elitehair.com",
                phone: "+91 98765 43210",
                address: "Shop 15, MG Road, Mumbai",
                category: "Salon",
                subscriptionTier: "Pro",
                status: "approved",
                rating: 4.8,
                totalBookings: 342,
                totalRevenue: 171000,
                joinDate: "2025-08-15",
                qrCode: "https://noo-q.app/book/elite-hair-studio",
                businessHours: {
                    monday: {start: "09:00", end: "20:00", isOpen: true},
                    tuesday: {start: "09:00", end: "20:00", isOpen: true},
                    wednesday: {start: "09:00", end: "20:00", isOpen: true},
                    thursday: {start: "09:00", end: "20:00", isOpen: true},
                    friday: {start: "09:00", end: "20:00", isOpen: true},
                    saturday: {start: "09:00", end: "22:00", isOpen: true},
                    sunday: {start: "10:00", end: "18:00", isOpen: true}
                },
                notifications: {
                    whatsapp: true,
                    sms: false,
                    email: true,
                    inSystem: true
                }
            },
            services: [
                {id: "svc_001", name: "Premium Haircut & Styling", category: "Hair Care", duration: 45, price: 500, description: "Professional haircut with premium styling", isActive: true, bookingCount: 89},
                {id: "svc_002", name: "Hair Wash & Blow Dry", category: "Hair Care", duration: 30, price: 300, description: "Luxurious hair wash with professional blow dry", isActive: true, bookingCount: 67},
                {id: "svc_003", name: "Beard Grooming & Trim", category: "Grooming", duration: 20, price: 200, description: "Precision beard trimming and styling", isActive: true, bookingCount: 45},
                {id: "svc_004", name: "Hair Coloring", category: "Hair Treatment", duration: 120, price: 1500, description: "Professional hair coloring with premium products", isActive: true, bookingCount: 23},
                {id: "svc_005", name: "Home Service Haircut", category: "Home Service", duration: 60, price: 800, description: "Premium haircut service at your location", isActive: true, bookingCount: 12}
            ],
            customers: [
                {id: "cust_001", name: "Amit Patel", phone: "+91 98765 11111", email: "amit@example.com", lastVisit: "2025-09-20", totalVisits: 12, totalSpent: 6000, preferredServices: ["Premium Haircut & Styling"], notes: "Prefers short hairstyles, allergic to certain hair products", loyalty: "Gold", nextAppointment: "2025-09-26"},
                {id: "cust_002", name: "Rohit Singh", phone: "+91 98765 22222", email: "rohit@example.com", lastVisit: "2025-09-18", totalVisits: 8, totalSpent: 2400, preferredServices: ["Beard Grooming & Trim"], notes: "Regular customer, prefers weekend appointments", loyalty: "Silver", nextAppointment: "2025-09-28"},
                {id: "cust_003", name: "Vikash Kumar", phone: "+91 98765 33333", email: "vikash@example.com", lastVisit: "2025-09-15", totalVisits: 15, totalSpent: 7500, preferredServices: ["Premium Haircut & Styling", "Hair Coloring"], notes: "VIP customer, books monthly hair coloring", loyalty: "Platinum", nextAppointment: "2025-10-01"}
            ],
            appointments: [
                {id: "appt_001", customerId: "cust_001", customerName: "Amit Patel", serviceId: "svc_001", serviceName: "Premium Haircut & Styling", date: "2025-09-26", time: "14:00", duration: 45, status: "confirmed", amount: 500, paymentStatus: "paid", type: "regular", notes: "Customer requested shorter style"},
                {id: "appt_002", customerId: "cust_002", customerName: "Rohit Singh", serviceId: "svc_003", serviceName: "Beard Grooming & Trim", date: "2025-09-26", time: "16:30", duration: 20, status: "confirmed", amount: 200, paymentStatus: "paid", type: "regular", notes: "Regular maintenance trim"},
                {id: "appt_003", customerId: "cust_003", customerName: "Vikash Kumar", serviceId: "svc_004", serviceName: "Hair Coloring", date: "2025-09-27", time: "10:00", duration: 120, status: "pending", amount: 1500, paymentStatus: "unpaid", type: "regular", notes: "Monthly color touch-up"}
            ],
            inventory: [
                {id: "inv_001", name: "Premium Shampoo", category: "Hair Care", currentStock: 24, minStock: 10, maxStock: 50, unitPrice: 450, supplier: "L'Oreal Professional", lastOrdered: "2025-09-15", expiryDate: "2026-08-15"},
                {id: "inv_002", name: "Hair Color - Brown", category: "Hair Treatment", currentStock: 8, minStock: 5, maxStock: 20, unitPrice: 850, supplier: "Matrix", lastOrdered: "2025-09-10", expiryDate: "2025-12-20"},
                {id: "inv_003", name: "Styling Gel", category: "Styling", currentStock: 3, minStock: 8, maxStock: 30, unitPrice: 320, supplier: "Wella", lastOrdered: "2025-08-28", expiryDate: "2026-05-10"},
                {id: "inv_004", name: "Disposable Towels", category: "Supplies", currentStock: 150, minStock: 50, maxStock: 300, unitPrice: 2, supplier: "Local Supplier", lastOrdered: "2025-09-20", expiryDate: "2026-12-31"}
            ],
            analytics: {
                revenue: {today: 1200, thisWeek: 8500, thisMonth: 34000, lastMonth: 29000, growth: "+17.2%"},
                bookings: {today: 6, thisWeek: 42, thisMonth: 178, lastMonth: 156, growth: "+14.1%"},
                customers: {total: 89, new: 12, returning: 77, retention: "86.5%"},
                popular_services: [
                    {name: "Premium Haircut & Styling", bookings: 89, revenue: 44500},
                    {name: "Hair Wash & Blow Dry", bookings: 67, revenue: 20100},
                    {name: "Beard Grooming & Trim", bookings: 45, revenue: 9000}
                ]
            },
            promotions: [
                {id: "promo_001", name: "Weekend Special", discount: 20, validFrom: "2025-09-28", validTo: "2025-09-29", applicableServices: ["svc_001", "svc_002"], isActive: true},
                {id: "promo_002", name: "New Customer Offer", discount: 15, validFrom: "2025-09-01", validTo: "2025-12-31", applicableServices: ["all"], isActive: true}
            ],
            notifications: [
                {id: "notif_001", type: "booking_confirmed", customer: "Amit Patel", message: "Appointment confirmed for Sept 26, 2:00 PM", channel: "whatsapp", status: "delivered", timestamp: "2025-09-25T14:30:00Z"},
                {id: "notif_002", type: "inventory_alert", item: "Styling Gel", message: "Stock running low - only 3 units remaining", channel: "system", status: "unread", timestamp: "2025-09-25T09:15:00Z"},
                {id: "notif_003", type: "customer_reminder", customer: "Vikash Kumar", message: "Reminder: Hair coloring appointment tomorrow", channel: "sms", status: "delivered", timestamp: "2025-09-26T18:00:00Z"}
            ]
        };
        
        this.init();
    }
    
    init() {
        console.log('🚀 Initializing Service Provider App...');
        this.setupEventListeners();
        this.loadBusinessInfo();
        this.setupNotifications();
        this.showSection('dashboard');
        console.log('✅ App initialized successfully');
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.showSection(section);
            });
        });
        
        // Sidebar toggle
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }
        
        // QR Code button
        const qrCodeBtn = document.querySelector('.qr-code-btn');
        if (qrCodeBtn) {
            qrCodeBtn.addEventListener('click', () => {
                this.showQRModal();
            });
        }
        
        // Notifications - Fix the event listener
        const notificationsBtn = document.getElementById('notificationsBtn');
        if (notificationsBtn) {
            notificationsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleNotifications();
            });
        }
        
        // Close notifications dropdown when clicking elsewhere
        document.addEventListener('click', (e) => {
            const notificationDropdown = document.getElementById('notificationDropdown');
            const notificationsBtn = document.getElementById('notificationsBtn');
            
            if (notificationDropdown && !notificationDropdown.classList.contains('hidden')) {
                if (!notificationDropdown.contains(e.target) && !notificationsBtn.contains(e.target)) {
                    this.closeNotifications();
                }
            }
        });
        
        // Appointment filter
        const appointmentFilter = document.getElementById('appointmentFilter');
        if (appointmentFilter) {
            appointmentFilter.addEventListener('change', (e) => {
                this.filterAppointments(e.target.value);
            });
        }
        
        // Customer search
        const customerSearch = document.getElementById('customerSearch');
        if (customerSearch) {
            customerSearch.addEventListener('input', (e) => {
                this.searchCustomers(e.target.value);
            });
        }
        
        // Analytics filter
        const analyticsFilter = document.getElementById('analyticsFilter');
        if (analyticsFilter) {
            analyticsFilter.addEventListener('change', (e) => {
                this.updateAnalytics(e.target.value);
            });
        }
        
        // Close modals when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });
        
        // Mobile responsive
        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024 && this.sidebarOpen) {
                this.closeSidebar();
            }
        });
    }
    
    loadBusinessInfo() {
        const provider = this.data.currentProvider;
        document.getElementById('businessName').textContent = provider.businessName;
        document.getElementById('subscriptionTier').textContent = `${provider.subscriptionTier} Plan`;
        document.querySelector('.user-name').textContent = provider.ownerName;
        document.querySelector('.user-avatar').textContent = provider.ownerName.charAt(0);
    }
    
    showSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
        
        // Update content
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${sectionName}Section`).classList.add('active');
        
        // Update page title
        const titles = {
            dashboard: 'Dashboard',
            appointments: 'Appointments',
            customers: 'Customers',
            services: 'Services',
            inventory: 'Inventory',
            analytics: 'Analytics',
            promotions: 'Promotions',
            settings: 'Settings'
        };
        document.getElementById('pageTitle').textContent = titles[sectionName] || sectionName;
        
        // Load section-specific content
        this.loadSectionContent(sectionName);
        
        // Close sidebar on mobile
        if (window.innerWidth <= 1024) {
            this.closeSidebar();
        }
        
        this.currentSection = sectionName;
    }
    
    loadSectionContent(sectionName) {
        switch(sectionName) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'appointments':
                this.loadAppointments();
                break;
            case 'customers':
                this.loadCustomers();
                break;
            case 'services':
                this.loadServices();
                break;
            case 'inventory':
                this.loadInventory();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
            case 'promotions':
                this.loadPromotions();
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }
    
    loadDashboard() {
        // Update stats
        const analytics = this.data.analytics;
        document.getElementById('todayAppointments').textContent = analytics.bookings.today;
        document.getElementById('todayRevenue').textContent = `₹${analytics.revenue.today.toLocaleString()}`;
        document.getElementById('totalCustomers').textContent = analytics.customers.total;
        
        // Count low stock items
        const lowStockItems = this.data.inventory.filter(item => item.currentStock <= item.minStock).length;
        document.getElementById('lowStockItems').textContent = lowStockItems;
        
        // Load today's schedule
        this.loadTodaySchedule();
    }
    
    loadTodaySchedule() {
        const container = document.getElementById('todaySchedule');
        const today = new Date().toISOString().split('T')[0];
        const todayAppointments = this.data.appointments.filter(apt => apt.date >= today);
        
        if (todayAppointments.length === 0) {
            container.innerHTML = '<p class="text-center" style="color: var(--color-text-secondary); padding: 2rem;">No appointments scheduled for today</p>';
            return;
        }
        
        container.innerHTML = todayAppointments.map(apt => `
            <div class="schedule-item" onclick="app.showAppointmentDetails('${apt.id}')">
                <div class="schedule-time">${this.formatTime(apt.time)}</div>
                <div class="schedule-service">
                    <div class="schedule-service-name">${apt.serviceName}</div>
                    <div class="schedule-customer">${apt.customerName}</div>
                </div>
                <div class="schedule-status">
                    <span class="status status--${apt.status === 'confirmed' ? 'success' : apt.status === 'pending' ? 'warning' : 'info'}">${this.capitalizeFirst(apt.status)}</span>
                </div>
            </div>
        `).join('');
    }
    
    loadAppointments() {
        const container = document.getElementById('appointmentsList');
        const appointments = this.data.appointments;
        
        container.innerHTML = appointments.map(apt => `
            <div class="appointment-card" onclick="app.showAppointmentDetails('${apt.id}')">
                <div class="appointment-header">
                    <div class="appointment-info">
                        <h4>${apt.serviceName}</h4>
                        <div class="appointment-time">${this.formatDate(apt.date)} at ${this.formatTime(apt.time)}</div>
                        <div class="appointment-customer">Customer: ${apt.customerName}</div>
                    </div>
                    <span class="status status--${apt.status === 'confirmed' ? 'success' : apt.status === 'pending' ? 'warning' : 'info'}">${this.capitalizeFirst(apt.status)}</span>
                </div>
                <div class="appointment-actions">
                    <button class="btn btn--outline btn--sm" onclick="event.stopPropagation(); app.rescheduleAppointment('${apt.id}')">Reschedule</button>
                    <button class="btn btn--primary btn--sm" onclick="event.stopPropagation(); app.confirmAppointment('${apt.id}')">Confirm</button>
                    <button class="btn btn--outline btn--sm" onclick="event.stopPropagation(); app.cancelAppointment('${apt.id}')">Cancel</button>
                </div>
            </div>
        `).join('');
    }
    
    loadCustomers() {
        const container = document.getElementById('customersList');
        const customers = this.data.customers;
        
        container.innerHTML = customers.map(customer => `
            <div class="customer-card" onclick="app.showCustomerDetails('${customer.id}')">
                <div class="customer-header">
                    <div class="customer-avatar">${customer.name.charAt(0)}</div>
                    <div class="customer-info">
                        <h4>${customer.name}</h4>
                        <div class="customer-contact">${customer.phone}</div>
                    </div>
                </div>
                <div class="customer-stats">
                    <div class="customer-stat">
                        <div class="customer-stat-value">${customer.totalVisits}</div>
                        <div class="customer-stat-label">Visits</div>
                    </div>
                    <div class="customer-stat">
                        <div class="customer-stat-value">₹${customer.totalSpent.toLocaleString()}</div>
                        <div class="customer-stat-label">Spent</div>
                    </div>
                    <div class="customer-stat">
                        <div class="customer-stat-value">${customer.loyalty}</div>
                        <div class="customer-stat-label">Status</div>
                    </div>
                </div>
                <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
                    Last visit: ${this.formatDate(customer.lastVisit)}
                </div>
            </div>
        `).join('');
    }
    
    loadServices() {
        const container = document.getElementById('servicesList');
        const services = this.data.services;
        
        container.innerHTML = services.map(service => `
            <div class="service-card">
                <div class="service-header">
                    <div class="service-info">
                        <h4>${service.name}</h4>
                        <div class="service-description">${service.description}</div>
                    </div>
                    <div class="service-price">₹${service.price}</div>
                </div>
                <div class="service-meta">
                    <span>${service.duration} minutes</span>
                    <span>${service.bookingCount} bookings</span>
                </div>
                <div class="service-actions">
                    <button class="btn btn--outline btn--sm" onclick="app.editService('${service.id}')">Edit</button>
                    <button class="btn btn--${service.isActive ? 'outline' : 'primary'} btn--sm" onclick="app.toggleService('${service.id}')">
                        ${service.isActive ? 'Disable' : 'Enable'}
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    loadInventory() {
        const container = document.getElementById('inventoryList');
        const inventory = this.data.inventory;
        
        container.innerHTML = inventory.map(item => {
            const stockStatus = item.currentStock <= item.minStock ? 'low-stock' : 
                              item.currentStock === 0 ? 'out-of-stock' : '';
            
            return `
                <div class="inventory-card ${stockStatus}">
                    <div class="inventory-header">
                        <div class="inventory-info">
                            <h4>${item.name}</h4>
                            <div class="inventory-category">${item.category}</div>
                        </div>
                        <div class="stock-level">
                            <div class="stock-current">${item.currentStock}</div>
                            <div class="stock-label">In Stock</div>
                        </div>
                    </div>
                    <div class="inventory-details">
                        <div>Min Stock: ${item.minStock}</div>
                        <div>Max Stock: ${item.maxStock}</div>
                        <div>Unit Price: ₹${item.unitPrice}</div>
                        <div>Supplier: ${item.supplier}</div>
                    </div>
                    ${item.currentStock <= item.minStock ? 
                        '<div style="color: var(--color-warning); font-size: var(--font-size-sm); margin-top: var(--space-8);">⚠️ Low Stock Alert</div>' : ''}
                </div>
            `;
        }).join('');
    }
    
    loadAnalytics() {
        // Load revenue chart
        this.loadRevenueChart();
        
        // Load services chart
        this.loadServicesChart();
    }
    
    loadRevenueChart() {
        const ctx = document.getElementById('revenueChart');
        if (!ctx) return;
        
        // Destroy existing chart
        if (this.charts.revenue) {
            this.charts.revenue.destroy();
        }
        
        // Sample revenue data for the last 7 days
        const labels = ['Sep 19', 'Sep 20', 'Sep 21', 'Sep 22', 'Sep 23', 'Sep 24', 'Sep 25'];
        const data = [800, 1200, 900, 1500, 1100, 1300, 1200];
        
        this.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Daily Revenue',
                    data: data,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    loadServicesChart() {
        const ctx = document.getElementById('servicesChart');
        if (!ctx) return;
        
        // Destroy existing chart
        if (this.charts.services) {
            this.charts.services.destroy();
        }
        
        const popularServices = this.data.analytics.popular_services;
        const labels = popularServices.map(service => service.name);
        const data = popularServices.map(service => service.bookings);
        
        this.charts.services = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    loadPromotions() {
        const container = document.getElementById('promotionsList');
        const promotions = this.data.promotions;
        
        container.innerHTML = promotions.map(promo => `
            <div class="promotion-card">
                <div class="promotion-header">
                    <div class="promotion-info">
                        <h4>${promo.name}</h4>
                        <div class="promotion-validity">Valid: ${this.formatDate(promo.validFrom)} - ${this.formatDate(promo.validTo)}</div>
                    </div>
                    <div class="promotion-discount">${promo.discount}% OFF</div>
                </div>
                <div class="promotion-services">
                    Applicable to: ${promo.applicableServices.includes('all') ? 'All Services' : promo.applicableServices.length + ' services'}
                </div>
                <div style="margin-top: var(--space-12);">
                    <span class="status status--${promo.isActive ? 'success' : 'info'}">${promo.isActive ? 'Active' : 'Inactive'}</span>
                </div>
            </div>
        `).join('');
    }
    
    loadSettings() {
        const businessContainer = document.getElementById('businessSettings');
        const notificationContainer = document.getElementById('notificationSettings');
        const provider = this.data.currentProvider;
        
        businessContainer.innerHTML = `
            <div class="form-group">
                <label class="form-label">Business Name</label>
                <input type="text" class="form-control" value="${provider.businessName}">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Owner Name</label>
                    <input type="text" class="form-control" value="${provider.ownerName}">
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input type="tel" class="form-control" value="${provider.phone}">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" value="${provider.email}">
            </div>
            <div class="form-group">
                <label class="form-label">Address</label>
                <textarea class="form-control" rows="3">${provider.address}</textarea>
            </div>
            <button class="btn btn--primary">Save Changes</button>
        `;
        
        notificationContainer.innerHTML = `
            <div class="toggle-setting">
                <label>WhatsApp Notifications</label>
                <div class="toggle-switch ${provider.notifications.whatsapp ? 'active' : ''}" onclick="app.toggleNotificationSetting('whatsapp')"></div>
            </div>
            <div class="toggle-setting">
                <label>SMS Notifications</label>
                <div class="toggle-switch ${provider.notifications.sms ? 'active' : ''}" onclick="app.toggleNotificationSetting('sms')"></div>
            </div>
            <div class="toggle-setting">
                <label>Email Notifications</label>
                <div class="toggle-switch ${provider.notifications.email ? 'active' : ''}" onclick="app.toggleNotificationSetting('email')"></div>
            </div>
            <div class="toggle-setting">
                <label>In-System Notifications</label>
                <div class="toggle-switch ${provider.notifications.inSystem ? 'active' : ''}" onclick="app.toggleNotificationSetting('inSystem')"></div>
            </div>
        `;
    }
    
    // Appointment Management
    showAppointmentDetails(appointmentId) {
        const appointment = this.data.appointments.find(apt => apt.id === appointmentId);
        if (!appointment) return;
        
        const customer = this.data.customers.find(c => c.id === appointment.customerId);
        const service = this.data.services.find(s => s.id === appointment.serviceId);
        
        document.getElementById('appointmentDetails').innerHTML = `
            <div class="appointment-detail-grid" style="display: grid; gap: var(--space-20);">
                <div class="card">
                    <div class="card__header">
                        <h4>Appointment Information</h4>
                    </div>
                    <div class="card__body">
                        <div style="display: grid; gap: var(--space-12);">
                            <div><strong>Service:</strong> ${appointment.serviceName}</div>
                            <div><strong>Date:</strong> ${this.formatDate(appointment.date)}</div>
                            <div><strong>Time:</strong> ${this.formatTime(appointment.time)}</div>
                            <div><strong>Duration:</strong> ${appointment.duration} minutes</div>
                            <div><strong>Amount:</strong> ₹${appointment.amount}</div>
                            <div><strong>Status:</strong> <span class="status status--${appointment.status === 'confirmed' ? 'success' : 'warning'}">${this.capitalizeFirst(appointment.status)}</span></div>
                            <div><strong>Payment:</strong> <span class="status status--${appointment.paymentStatus === 'paid' ? 'success' : 'warning'}">${this.capitalizeFirst(appointment.paymentStatus)}</span></div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card__header">
                        <h4>Customer Information</h4>
                    </div>
                    <div class="card__body">
                        <div style="display: grid; gap: var(--space-12);">
                            <div><strong>Name:</strong> ${customer?.name || 'N/A'}</div>
                            <div><strong>Phone:</strong> ${customer?.phone || 'N/A'}</div>
                            <div><strong>Email:</strong> ${customer?.email || 'N/A'}</div>
                            <div><strong>Total Visits:</strong> ${customer?.totalVisits || 0}</div>
                            <div><strong>Loyalty Status:</strong> ${customer?.loyalty || 'Regular'}</div>
                        </div>
                    </div>
                </div>
                
                ${appointment.notes ? `
                <div class="card">
                    <div class="card__header">
                        <h4>Notes</h4>
                    </div>
                    <div class="card__body">
                        <p>${appointment.notes}</p>
                    </div>
                </div>
                ` : ''}
                
                <div class="appointment-actions" style="display: flex; gap: var(--space-12); justify-content: center;">
                    <button class="btn btn--outline" onclick="app.rescheduleAppointment('${appointment.id}')">Reschedule</button>
                    <button class="btn btn--primary" onclick="app.confirmAppointment('${appointment.id}')">Confirm</button>
                    <button class="btn btn--outline" onclick="app.cancelAppointment('${appointment.id}')">Cancel</button>
                </div>
            </div>
        `;
        
        this.showModal('appointmentModal');
    }
    
    confirmAppointment(appointmentId) {
        const appointment = this.data.appointments.find(apt => apt.id === appointmentId);
        if (appointment) {
            appointment.status = 'confirmed';
            this.showToast('success', 'Appointment Confirmed', `Appointment for ${appointment.customerName} has been confirmed.`);
            this.loadSectionContent(this.currentSection);
            this.closeModal('appointmentModal');
        }
    }
    
    rescheduleAppointment(appointmentId) {
        this.showToast('info', 'Reschedule', 'Reschedule functionality would open a date/time picker here.');
    }
    
    cancelAppointment(appointmentId) {
        const appointment = this.data.appointments.find(apt => apt.id === appointmentId);
        if (appointment) {
            appointment.status = 'cancelled';
            this.showToast('warning', 'Appointment Cancelled', `Appointment for ${appointment.customerName} has been cancelled.`);
            this.loadSectionContent(this.currentSection);
            this.closeModal('appointmentModal');
        }
    }
    
    // Customer Management
    showCustomerDetails(customerId) {
        const customer = this.data.customers.find(c => c.id === customerId);
        if (!customer) return;
        
        const customerAppointments = this.data.appointments.filter(apt => apt.customerId === customerId);
        
        document.getElementById('customerDetails').innerHTML = `
            <div class="customer-detail-grid" style="display: grid; gap: var(--space-20);">
                <div class="card">
                    <div class="card__header">
                        <h4>Customer Profile</h4>
                    </div>
                    <div class="card__body">
                        <div style="display: grid; gap: var(--space-12);">
                            <div><strong>Name:</strong> ${customer.name}</div>
                            <div><strong>Phone:</strong> ${customer.phone}</div>
                            <div><strong>Email:</strong> ${customer.email}</div>
                            <div><strong>Total Visits:</strong> ${customer.totalVisits}</div>
                            <div><strong>Total Spent:</strong> ₹${customer.totalSpent.toLocaleString()}</div>
                            <div><strong>Loyalty Status:</strong> <span class="status status--info">${customer.loyalty}</span></div>
                            <div><strong>Last Visit:</strong> ${this.formatDate(customer.lastVisit)}</div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card__header">
                        <h4>Preferred Services</h4>
                    </div>
                    <div class="card__body">
                        <div style="display: flex; flex-wrap: wrap; gap: var(--space-8);">
                            ${customer.preferredServices.map(service => `<span class="status status--info">${service}</span>`).join('')}
                        </div>
                    </div>
                </div>
                
                ${customer.notes ? `
                <div class="card">
                    <div class="card__header">
                        <h4>Notes</h4>
                    </div>
                    <div class="card__body">
                        <p>${customer.notes}</p>
                    </div>
                </div>
                ` : ''}
                
                <div class="card">
                    <div class="card__header">
                        <h4>Appointment History</h4>
                    </div>
                    <div class="card__body">
                        ${customerAppointments.length > 0 ? `
                            <div style="display: grid; gap: var(--space-12);">
                                ${customerAppointments.map(apt => `
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding: var(--space-8); background: var(--color-bg-1); border-radius: var(--radius-base);">
                                        <div>
                                            <strong>${apt.serviceName}</strong><br>
                                            <small>${this.formatDate(apt.date)} at ${this.formatTime(apt.time)}</small>
                                        </div>
                                        <span class="status status--${apt.status === 'confirmed' ? 'success' : 'warning'}">${this.capitalizeFirst(apt.status)}</span>
                                    </div>
                                `).join('')}
                            </div>
                        ` : '<p>No appointment history found.</p>'}
                    </div>
                </div>
            </div>
        `;
        
        this.showModal('customerModal');
    }
    
    // Service Management
    showAddServiceModal() {
        this.showToast('info', 'Add Service', 'Add service modal would open here with a form to create new services.');
    }
    
    editService(serviceId) {
        this.showToast('info', 'Edit Service', `Edit service ${serviceId} modal would open here.`);
    }
    
    toggleService(serviceId) {
        const service = this.data.services.find(s => s.id === serviceId);
        if (service) {
            service.isActive = !service.isActive;
            this.showToast('success', 'Service Updated', `${service.name} has been ${service.isActive ? 'enabled' : 'disabled'}.`);
            this.loadServices();
        }
    }
    
    // Inventory Management
    showAddInventoryModal() {
        this.showToast('info', 'Add Inventory', 'Add inventory item modal would open here.');
    }
    
    showInventoryAlert() {
        const lowStockItems = this.data.inventory.filter(item => item.currentStock <= item.minStock);
        if (lowStockItems.length > 0) {
            this.showToast('warning', 'Low Stock Alert', `${lowStockItems.length} items are running low on stock.`);
        } else {
            this.showToast('success', 'Inventory OK', 'All items are well-stocked.');
        }
    }
    
    // Promotions Management
    showCreatePromotionModal() {
        this.showToast('info', 'Create Promotion', 'Create promotion modal would open here with discount and validity settings.');
    }
    
    // QR Code Management
    showQRModal() {
        document.getElementById('qrUrl').textContent = this.data.currentProvider.qrCode;
        this.showModal('qrModal');
    }
    
    copyQRUrl() {
        const url = document.getElementById('qrUrl').textContent;
        navigator.clipboard.writeText(url).then(() => {
            this.showToast('success', 'Link Copied', 'QR code link has been copied to clipboard.');
        }).catch(() => {
            this.showToast('error', 'Copy Failed', 'Unable to copy link to clipboard.');
        });
    }
    
    downloadQR() {
        this.showToast('info', 'Download QR', 'QR code download would start here.');
    }
    
    printQR() {
        this.showToast('info', 'Print QR', 'Print dialog would open here.');
    }
    
    // Settings Management
    toggleNotificationSetting(type) {
        this.data.currentProvider.notifications[type] = !this.data.currentProvider.notifications[type];
        const toggle = event.target;
        toggle.classList.toggle('active');
        this.showToast('success', 'Settings Updated', `${this.capitalizeFirst(type)} notifications ${this.data.currentProvider.notifications[type] ? 'enabled' : 'disabled'}.`);
    }
    
    // Filter and Search Functions
    filterAppointments(filter) {
        const today = new Date().toISOString().split('T')[0];
        const thisWeek = new Date();
        thisWeek.setDate(thisWeek.getDate() + 7);
        const thisWeekStr = thisWeek.toISOString().split('T')[0];
        
        let filteredAppointments = this.data.appointments;
        
        switch(filter) {
            case 'today':
                filteredAppointments = this.data.appointments.filter(apt => apt.date === today);
                break;
            case 'week':
                filteredAppointments = this.data.appointments.filter(apt => apt.date >= today && apt.date <= thisWeekStr);
                break;
            case 'pending':
                filteredAppointments = this.data.appointments.filter(apt => apt.status === 'pending');
                break;
            case 'confirmed':
                filteredAppointments = this.data.appointments.filter(apt => apt.status === 'confirmed');
                break;
        }
        
        // Update the appointments list with filtered data
        const container = document.getElementById('appointmentsList');
        container.innerHTML = filteredAppointments.map(apt => `
            <div class="appointment-card" onclick="app.showAppointmentDetails('${apt.id}')">
                <div class="appointment-header">
                    <div class="appointment-info">
                        <h4>${apt.serviceName}</h4>
                        <div class="appointment-time">${this.formatDate(apt.date)} at ${this.formatTime(apt.time)}</div>
                        <div class="appointment-customer">Customer: ${apt.customerName}</div>
                    </div>
                    <span class="status status--${apt.status === 'confirmed' ? 'success' : apt.status === 'pending' ? 'warning' : 'info'}">${this.capitalizeFirst(apt.status)}</span>
                </div>
                <div class="appointment-actions">
                    <button class="btn btn--outline btn--sm" onclick="event.stopPropagation(); app.rescheduleAppointment('${apt.id}')">Reschedule</button>
                    <button class="btn btn--primary btn--sm" onclick="event.stopPropagation(); app.confirmAppointment('${apt.id}')">Confirm</button>
                    <button class="btn btn--outline btn--sm" onclick="event.stopPropagation(); app.cancelAppointment('${apt.id}')">Cancel</button>
                </div>
            </div>
        `).join('');
    }
    
    searchCustomers(query) {
        const filteredCustomers = this.data.customers.filter(customer => 
            customer.name.toLowerCase().includes(query.toLowerCase()) ||
            customer.phone.includes(query) ||
            customer.email.toLowerCase().includes(query.toLowerCase())
        );
        
        const container = document.getElementById('customersList');
        container.innerHTML = filteredCustomers.map(customer => `
            <div class="customer-card" onclick="app.showCustomerDetails('${customer.id}')">
                <div class="customer-header">
                    <div class="customer-avatar">${customer.name.charAt(0)}</div>
                    <div class="customer-info">
                        <h4>${customer.name}</h4>
                        <div class="customer-contact">${customer.phone}</div>
                    </div>
                </div>
                <div class="customer-stats">
                    <div class="customer-stat">
                        <div class="customer-stat-value">${customer.totalVisits}</div>
                        <div class="customer-stat-label">Visits</div>
                    </div>
                    <div class="customer-stat">
                        <div class="customer-stat-value">₹${customer.totalSpent.toLocaleString()}</div>
                        <div class="customer-stat-label">Spent</div>
                    </div>
                    <div class="customer-stat">
                        <div class="customer-stat-value">${customer.loyalty}</div>
                        <div class="customer-stat-label">Status</div>
                    </div>
                </div>
                <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
                    Last visit: ${this.formatDate(customer.lastVisit)}
                </div>
            </div>
        `).join('');
    }
    
    updateAnalytics(period) {
        this.showToast('info', 'Analytics Updated', `Analytics view updated for ${period}.`);
        // In a real app, this would fetch new data and update charts
        this.loadAnalytics();
    }
    
    // Notification System - Fixed implementation
    setupNotifications() {
        this.loadNotificationsList();
        this.updateNotificationBadge();
    }
    
    loadNotificationsList() {
        const container = document.getElementById('notificationsList');
        const notifications = this.data.notifications;
        
        if (!container) return;
        
        container.innerHTML = notifications.map(notif => `
            <div class="notification-item ${notif.status === 'unread' ? 'unread' : ''}" onclick="app.markNotificationRead('${notif.id}')">
                <div class="notification-content">
                    <div class="notification-title">${this.getNotificationTitle(notif.type)}</div>
                    <div class="notification-message">${notif.message}</div>
                    <div class="notification-time">${this.formatRelativeTime(notif.timestamp)}</div>
                </div>
            </div>
        `).join('');
    }
    
    toggleNotifications() {
        const dropdown = document.getElementById('notificationDropdown');
        if (!dropdown) return;
        
        dropdown.classList.toggle('hidden');
        
        // Position the dropdown correctly
        const notificationsBtn = document.getElementById('notificationsBtn');
        if (notificationsBtn && !dropdown.classList.contains('hidden')) {
            const btnRect = notificationsBtn.getBoundingClientRect();
            dropdown.style.position = 'fixed';
            dropdown.style.top = (btnRect.bottom + 8) + 'px';
            dropdown.style.right = (window.innerWidth - btnRect.right) + 'px';
        }
    }
    
    closeNotifications() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            dropdown.classList.add('hidden');
        }
    }
    
    markNotificationRead(notificationId) {
        const notification = this.data.notifications.find(n => n.id === notificationId);
        if (notification && notification.status === 'unread') {
            notification.status = 'read';
            this.loadNotificationsList();
            this.updateNotificationBadge();
        }
    }
    
    markAllNotificationsRead() {
        this.data.notifications.forEach(notif => notif.status = 'read');
        this.loadNotificationsList();
        this.updateNotificationBadge();
        this.showToast('success', 'Notifications', 'All notifications marked as read.');
    }
    
    updateNotificationBadge() {
        const unreadCount = this.data.notifications.filter(n => n.status === 'unread').length;
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }
    }
    
    // UI Helper Functions
    toggleSidebar() {
        this.sidebarOpen = !this.sidebarOpen;
        document.querySelector('.sidebar').classList.toggle('open', this.sidebarOpen);
    }
    
    closeSidebar() {
        this.sidebarOpen = false;
        document.querySelector('.sidebar').classList.remove('open');
    }
    
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }
    
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = '';
        }
    }
    
    showToast(type, title, message) {
        const container = document.getElementById('toastContainer');
        if (!container) return;
        
        const toastId = 'toast_' + Date.now();
        
        const toast = document.createElement('div');
        toast.className = `toast toast--${type}`;
        toast.id = toastId;
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="app.dismissToast('${toastId}')">&times;</button>
        `;
        
        container.appendChild(toast);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            this.dismissToast(toastId);
        }, 5000);
    }
    
    dismissToast(toastId) {
        const toast = document.getElementById(toastId);
        if (toast) {
            toast.classList.add('toast--dismissing');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }
    }
    
    // Utility Functions
    formatDate(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    }
    
    formatTime(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours > 12 ? hours - 12 : (hours === 0 ? 12 : hours);
        return `${displayHours}:${minutes.toString().padStart(2, '0')} ${period}`;
    }
    
    formatRelativeTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffDays > 0) {
            return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
        } else if (diffHours > 0) {
            return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
        } else {
            const diffMinutes = Math.floor(diffMs / (1000 * 60));
            return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`;
        }
    }
    
    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    
    getNotificationTitle(type) {
        const titles = {
            booking_confirmed: 'Booking Confirmed',
            inventory_alert: 'Inventory Alert',
            customer_reminder: 'Customer Reminder',
            payment_received: 'Payment Received',
            new_customer: 'New Customer'
        };
        return titles[type] || 'Notification';
    }
}

// Initialize the app
let app;

document.addEventListener('DOMContentLoaded', () => {
    try {
        app = new ServiceProviderApp();
        window.app = app; // Make available globally for onclick handlers
        console.log('🎉 Service Provider App loaded successfully!');
    } catch (error) {
        console.error('❌ Failed to initialize app:', error);
        
        // Show error message
        document.body.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; height: 100vh; text-align: center; padding: 20px;">
                <div>
                    <h1 style="color: #c01521; margin-bottom: 16px;">App Loading Failed</h1>
                    <p style="color: #626e71; margin-bottom: 24px;">There was an error loading the Service Provider Dashboard. Please refresh the page to try again.</p>
                    <button onclick="window.location.reload()" style="background: #217d8d; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer;">
                        Refresh Page
                    </button>
                </div>
            </div>
        `;
    }
});

// Handle app install prompt for PWA
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Show install notification after 5 seconds
    setTimeout(() => {
        if (app) {
            app.showToast('info', 'Install App', 'Add Noo-Q Provider Dashboard to your home screen for easier access!');
        }
    }, 5000);
});

// Handle app installation
window.addEventListener('appinstalled', () => {
    if (app) {
        app.showToast('success', 'App Installed', 'Noo-Q Provider Dashboard has been installed on your device!');
    }
    deferredPrompt = null;
});

// Service Worker Registration for PWA
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('✅ Service Worker registered'))
        .catch(err => console.log('❌ Service Worker registration failed:', err));
}

// Handle offline/online status
window.addEventListener('online', () => {
    if (app) {
        app.showToast('success', 'Connection Restored', 'You are back online!');
    }
});

window.addEventListener('offline', () => {
    if (app) {
        app.showToast('warning', 'No Internet', 'You are currently offline. Some features may not work.');
    }
});

// Keyboard shortcuts for power users
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        switch(e.key) {
            case '1':
                e.preventDefault();
                app && app.showSection('dashboard');
                break;
            case '2':
                e.preventDefault();
                app && app.showSection('appointments');
                break;
            case '3':
                e.preventDefault();
                app && app.showSection('customers');
                break;
            case '4':
                e.preventDefault();
                app && app.showSection('services');
                break;
            case '5':
                e.preventDefault();
                app && app.showSection('inventory');
                break;
            case '6':
                e.preventDefault();
                app && app.showSection('analytics');
                break;
        }
    }
});