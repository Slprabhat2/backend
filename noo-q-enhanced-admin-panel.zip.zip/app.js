// Noo-Q Admin Panel Application
class NooQAdminApp {
    constructor() {
        this.state = {
            currentUser: null,
            currentSection: 'overview',
            isLoggedIn: false,
            providers: [],
            transactions: [],
            notifications: [],
            analytics: {},
            charts: {},
            filters: {
                providerStatus: '',
                providerSearch: '',
                transactionStatus: '',
                transactionDateFrom: '',
                transactionDateTo: '',
                analyticsTimeframe: '30d'
            }
        };

        this.config = {
            appName: 'Noo-Q Admin Panel',
            version: '2.0.0',
            chartColors: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B']
        };

        // Sample data from application_data_json
        this.adminUser = {
            email: "admin@noo-q.com",
            password: "Admin123$",
            name: "Platform Administrator",
            role: "super_admin"
        };

        this.dashboardStats = {
            qrScans: {
                today: 1247,
                weekly: 8934,
                monthly: 34567,
                growth: "+12.5%"
            },
            transactions: {
                total: 2340000,
                serviceCharges: 2106000,
                convenienceFees: 234000,
                growth: "+8.7%"
            },
            users: {
                activeProviders: 156,
                activeCustomers: 12847,
                newSignups: 234,
                retention: "78.5%"
            },
            revenue: {
                today: 67890,
                monthly: 2340000,
                yearly: 28080000,
                projectedGrowth: "+15.2%"
            }
        };

        this.sampleProviders = [
            {"id": "prov_001", "name": "Elite Hair Studio", "owner": "Rajesh Kumar", "type": "Salon", "status": "approved", "rating": 4.8, "totalBookings": 342, "revenue": 171000, "joinDate": "2025-08-15", "lastActive": "2025-09-25T09:30:00Z"},
            {"id": "prov_002", "name": "Dr. Sharma Clinic", "owner": "Dr. Priya Sharma", "type": "Healthcare", "status": "approved", "rating": 4.9, "totalBookings": 198, "revenue": 237600, "joinDate": "2025-08-20", "lastActive": "2025-09-25T08:45:00Z"},
            {"id": "prov_003", "name": "Serenity Spa", "owner": "Anjali Mehta", "type": "Wellness", "status": "approved", "rating": 4.7, "totalBookings": 289, "revenue": 434000, "joinDate": "2025-07-22", "lastActive": "2025-09-25T10:15:00Z"},
            {"id": "prov_004", "name": "Pet Care Plus", "owner": "Dr. Vikram Singh", "type": "Pet Care", "status": "pending", "rating": 0, "totalBookings": 0, "revenue": 0, "joinDate": "2025-09-24T14:20:00Z", "lastActive": "2025-09-24T14:20:00Z"},
            {"id": "prov_005", "name": "Fitness Hub", "owner": "Arjun Patel", "type": "Fitness", "status": "approved", "rating": 4.6, "totalBookings": 156, "revenue": 78000, "joinDate": "2025-09-01", "lastActive": "2025-09-25T07:30:00Z"},
            {"id": "prov_006", "name": "Auto Care Center", "owner": "Ramesh Kumar", "type": "Automotive", "status": "suspended", "rating": 3.8, "totalBookings": 87, "revenue": 43500, "joinDate": "2025-08-10", "lastActive": "2025-09-20T16:20:00Z"}
        ];

        this.sampleTransactions = [
            {"id": "txn_001", "bookingId": "book_001", "amount": 500, "convenienceFee": 25, "providerAmount": 475, "date": "2025-09-25T14:30:00Z", "status": "completed", "method": "UPI", "providerName": "Elite Hair Studio"},
            {"id": "txn_002", "bookingId": "book_002", "amount": 800, "convenienceFee": 40, "providerAmount": 760, "date": "2025-09-25T10:45:00Z", "status": "completed", "method": "Card", "providerName": "Dr. Sharma Clinic"},
            {"id": "txn_003", "bookingId": "book_003", "amount": 2000, "convenienceFee": 100, "providerAmount": 1900, "date": "2025-09-25T16:15:00Z", "status": "completed", "method": "Wallet", "providerName": "Serenity Spa"},
            {"id": "txn_004", "bookingId": "book_004", "amount": 1200, "convenienceFee": 60, "providerAmount": 1140, "date": "2025-09-25T07:30:00Z", "status": "completed", "method": "UPI", "providerName": "Fitness Hub"},
            {"id": "txn_005", "bookingId": "book_005", "amount": 1500, "convenienceFee": 75, "providerAmount": 1425, "date": "2025-09-24T18:20:00Z", "status": "pending", "method": "UPI", "providerName": "Elite Hair Studio"},
            {"id": "txn_006", "bookingId": "book_006", "amount": 650, "convenienceFee": 32, "providerAmount": 618, "date": "2025-09-24T12:10:00Z", "status": "failed", "method": "Card", "providerName": "Dr. Sharma Clinic"}
        ];

        this.sampleNotifications = [
            {"id": "notif_001", "type": "provider_approval", "recipient": "prov_004", "channel": "email", "status": "pending", "message": "Your provider application is under review", "createdAt": "2025-09-24T14:25:00Z"},
            {"id": "notif_002", "type": "booking_confirmation", "recipient": "book_001", "channel": "whatsapp", "status": "delivered", "message": "Booking confirmed for Sept 26 at 2:00 PM", "createdAt": "2025-09-25T14:31:00Z"},
            {"id": "notif_003", "type": "payment_reminder", "recipient": "book_005", "channel": "sms", "status": "delivered", "message": "Payment pending for your booking", "createdAt": "2025-09-25T18:00:00Z"},
            {"id": "notif_004", "type": "system_maintenance", "recipient": "all_users", "channel": "whatsapp", "status": "delivered", "message": "System maintenance scheduled for tonight", "createdAt": "2025-09-25T10:00:00Z"},
            {"id": "notif_005", "type": "promotional", "recipient": "all_customers", "channel": "email", "status": "delivered", "message": "Special discount on wellness services", "createdAt": "2025-09-24T09:15:00Z"}
        ];

        this.analyticsData = {
            appointmentTrends: {
                healthcare: {"count": 245, "growth": "+15.2%"},
                salon: {"count": 423, "growth": "+8.7%"},
                wellness: {"count": 198, "growth": "+22.1%"},
                petcare: {"count": 89, "growth": "+45.3%"},
                fitness: {"count": 167, "growth": "+12.8%"}
            },
            customerBehavior: {
                newCustomers: 1247,
                repeatCustomers: 2893,
                retentionRate: "78.5%",
                averageBookings: 3.2
            },
            demandData: {
                topServices: ["Hair Cutting", "Health Checkup", "Massage Therapy"],
                peakHours: ["10:00-12:00", "14:00-16:00", "18:00-20:00"],
                popularDays: ["Saturday", "Sunday", "Wednesday"]
            }
        };

        this.marketInsights = {
            totalDemand: 15678,
            categoryGrowth: {
                healthcare: "+18%",
                beauty: "+12%",
                wellness: "+25%",
                automotive: "+8%"
            },
            geographicTrends: {
                mumbai: 4567,
                delhi: 3892,
                bangalore: 3234,
                chennai: 2156,
                hyderabad: 1829
            }
        };

        this.init();
    }

    init() {
        console.log('🚀 Initializing Noo-Q Admin Panel...');
        this.setupEventListeners();
        this.showLoginScreen();
        console.log('✅ Admin Panel initialized successfully');
    }

    setupEventListeners() {
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));

        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => this.handleLogout());

        // Provider management
        const providerSearch = document.getElementById('providerSearch');
        const providerStatusFilter = document.getElementById('providerStatusFilter');
        
        if (providerSearch) {
            providerSearch.addEventListener('input', (e) => this.handleProviderSearch(e));
        }
        if (providerStatusFilter) {
            providerStatusFilter.addEventListener('change', (e) => this.handleProviderFilter(e));
        }

        // Transaction filters
        const transactionDateFrom = document.getElementById('transactionDateFrom');
        const transactionDateTo = document.getElementById('transactionDateTo');
        const transactionStatusFilter = document.getElementById('transactionStatusFilter');
        
        if (transactionDateFrom) {
            transactionDateFrom.addEventListener('change', (e) => this.handleTransactionFilter());
        }
        if (transactionDateTo) {
            transactionDateTo.addEventListener('change', (e) => this.handleTransactionFilter());
        }
        if (transactionStatusFilter) {
            transactionStatusFilter.addEventListener('change', (e) => this.handleTransactionFilter());
        }

        // Export buttons
        const exportTransactionsBtn = document.getElementById('exportTransactionsBtn');
        const exportAnalyticsBtn = document.getElementById('exportAnalyticsBtn');
        
        if (exportTransactionsBtn) {
            exportTransactionsBtn.addEventListener('click', () => this.exportTransactions());
        }
        if (exportAnalyticsBtn) {
            exportAnalyticsBtn.addEventListener('click', () => this.exportAnalytics());
        }

        // Notification management
        const sendNotificationBtn = document.getElementById('sendNotificationBtn');
        const confirmSendNotification = document.getElementById('confirmSendNotification');
        
        if (sendNotificationBtn) {
            sendNotificationBtn.addEventListener('click', () => this.showSendNotificationModal());
        }
        if (confirmSendNotification) {
            confirmSendNotification.addEventListener('click', () => this.sendNotification());
        }

        // Modal controls
        this.setupModalControls();

        // Chart controls
        const scansPeriod = document.getElementById('scansPeriod');
        const analyticsTimeframe = document.getElementById('analyticsTimeframe');
        
        if (scansPeriod) {
            scansPeriod.addEventListener('change', (e) => this.updateScansChart(e.target.value));
        }
        if (analyticsTimeframe) {
            analyticsTimeframe.addEventListener('change', (e) => this.updateAnalyticsTimeframe(e.target.value));
        }
    }

    setupModalControls() {
        // Close modal buttons
        document.querySelectorAll('.modal-close, #closeProviderModal, #cancelNotification').forEach(btn => {
            btn.addEventListener('click', (e) => this.closeModals());
        });

        // Modal backdrop clicks
        document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
            backdrop.addEventListener('click', () => this.closeModals());
        });

        // Escape key to close modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModals();
            }
        });
    }

    // Authentication
    handleLogin(e) {
        e.preventDefault();
        
        const email = document.getElementById('adminEmail').value;
        const password = document.getElementById('adminPassword').value;
        
        this.showLoading('Authenticating...');
        
        // Simulate authentication delay
        setTimeout(() => {
            if (email === this.adminUser.email && password === this.adminUser.password) {
                this.state.currentUser = this.adminUser;
                this.state.isLoggedIn = true;
                this.hideLoading();
                this.showDashboard();
                this.showNotification('success', 'Welcome!', 'Successfully logged in to Admin Panel');
            } else {
                this.hideLoading();
                this.showNotification('error', 'Login Failed', 'Invalid email or password');
            }
        }, 1500);
    }

    handleLogout() {
        this.state.currentUser = null;
        this.state.isLoggedIn = false;
        
        // Clear form
        document.getElementById('loginForm').reset();
        
        this.showLoginScreen();
        this.showNotification('info', 'Logged Out', 'You have been logged out successfully');
    }

    showLoginScreen() {
        const loginScreen = document.getElementById('loginScreen');
        const dashboardScreen = document.getElementById('dashboardScreen');
        
        if (loginScreen) {
            loginScreen.style.display = 'flex';
            loginScreen.classList.add('active');
        }
        if (dashboardScreen) {
            dashboardScreen.style.display = 'none';
            dashboardScreen.classList.remove('active');
        }
    }

    showDashboard() {
        const loginScreen = document.getElementById('loginScreen');
        const dashboardScreen = document.getElementById('dashboardScreen');
        
        if (loginScreen) {
            loginScreen.style.display = 'none';
            loginScreen.classList.remove('active');
        }
        if (dashboardScreen) {
            dashboardScreen.style.display = 'flex';
            dashboardScreen.classList.add('active');
        }
        
        this.loadInitialData();
    }

    // Navigation
    handleNavigation(e) {
        e.preventDefault();
        const sectionName = e.target.getAttribute('data-section');
        
        if (sectionName) {
            this.showSection(sectionName);
        }
    }

    showSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        const activeLink = document.querySelector(`[data-section="${sectionName}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Update content sections
        document.querySelectorAll('.content-section').forEach(section => section.classList.remove('active'));
        const activeSection = document.getElementById(`${sectionName}Section`);
        if (activeSection) {
            activeSection.classList.add('active');
        }

        // Update header
        this.updateSectionHeader(sectionName);

        // Load section data
        this.loadSectionData(sectionName);

        this.state.currentSection = sectionName;
    }

    updateSectionHeader(sectionName) {
        const headers = {
            overview: {
                title: 'Platform Overview',
                subtitle: 'Monitor key metrics and platform performance'
            },
            providers: {
                title: 'Provider Management',
                subtitle: 'Manage service providers and their applications'
            },
            transactions: {
                title: 'Transaction Management',
                subtitle: 'Monitor payments and financial operations'
            },
            notifications: {
                title: 'Notification Management',
                subtitle: 'Send and track platform communications'
            },
            analytics: {
                title: 'Business Analytics',
                subtitle: 'Analyze trends and business performance'
            },
            insights: {
                title: 'Market Insights',
                subtitle: 'Data monetization and market intelligence'
            }
        };

        const header = headers[sectionName];
        if (header) {
            const titleEl = document.getElementById('sectionTitle');
            const subtitleEl = document.getElementById('sectionSubtitle');
            
            if (titleEl) titleEl.textContent = header.title;
            if (subtitleEl) subtitleEl.textContent = header.subtitle;
        }
    }

    loadInitialData() {
        this.state.providers = [...this.sampleProviders];
        this.state.transactions = [...this.sampleTransactions];
        this.state.notifications = [...this.sampleNotifications];
        this.state.analytics = {...this.analyticsData};
        
        this.showSection('overview');
    }

    loadSectionData(sectionName) {
        switch (sectionName) {
            case 'overview':
                this.loadOverviewData();
                break;
            case 'providers':
                this.loadProvidersData();
                break;
            case 'transactions':
                this.loadTransactionsData();
                break;
            case 'notifications':
                this.loadNotificationsData();
                break;
            case 'analytics':
                this.loadAnalyticsData();
                break;
            case 'insights':
                this.loadInsightsData();
                break;
        }
    }

    // Overview Section
    loadOverviewData() {
        this.loadRecentActivities();
        this.initializeCharts();
    }

    loadRecentActivities() {
        const activities = [
            {
                icon: 'user-plus',
                title: 'New Provider Application',
                description: 'Pet Care Plus submitted application for review',
                time: '2 hours ago',
                type: 'provider'
            },
            {
                icon: 'dollar-sign',
                title: 'High Value Transaction',
                description: '₹2,000 payment processed for Serenity Spa',
                time: '4 hours ago',
                type: 'transaction'
            },
            {
                icon: 'alert-circle',
                title: 'Provider Account Suspended',
                description: 'Auto Care Center suspended due to policy violation',
                time: '6 hours ago',
                type: 'alert'
            },
            {
                icon: 'trending-up',
                title: 'Revenue Milestone',
                description: 'Monthly revenue target achieved 5 days early',
                time: '1 day ago',
                type: 'milestone'
            }
        ];

        const container = document.getElementById('recentActivities');
        if (container) {
            container.innerHTML = activities.map(activity => `
                <div class="activity-item">
                    <div class="activity-icon">
                        ${this.getActivityIcon(activity.icon)}
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">${activity.title}</div>
                        <div class="activity-description">${activity.description}</div>
                        <div class="activity-time">${activity.time}</div>
                    </div>
                </div>
            `).join('');
        }
    }

    getActivityIcon(iconType) {
        const icons = {
            'user-plus': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>',
            'dollar-sign': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
            'alert-circle': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
            'trending-up': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>'
        };
        return icons[iconType] || icons['alert-circle'];
    }

    initializeCharts() {
        setTimeout(() => {
            this.createScansChart();
            this.createRevenueChart();
        }, 100);
    }

    createScansChart() {
        const ctx = document.getElementById('scansChart');
        if (!ctx || !window.Chart) return;

        // Generate sample data for last 30 days
        const days = [];
        const scansData = [];
        const today = new Date();
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(today.getDate() - i);
            days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            scansData.push(Math.floor(Math.random() * 800) + 400);
        }

        this.state.charts.scansChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: days,
                datasets: [{
                    label: 'QR Scans',
                    data: scansData,
                    borderColor: this.config.chartColors[0],
                    backgroundColor: this.config.chartColors[0] + '20',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    createRevenueChart() {
        const ctx = document.getElementById('revenueChart');
        if (!ctx || !window.Chart) return;

        this.state.charts.revenueChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Service Charges', 'Convenience Fees'],
                datasets: [{
                    data: [this.dashboardStats.transactions.serviceCharges, this.dashboardStats.transactions.convenienceFees],
                    backgroundColor: [this.config.chartColors[0], this.config.chartColors[1]],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    updateScansChart(period) {
        if (!this.state.charts.scansChart) return;
        
        // Update chart data based on period
        let days, scansData;
        
        switch (period) {
            case '7d':
                days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                scansData = [1200, 1100, 1400, 1300, 1600, 1800, 1500];
                break;
            case '90d':
                days = [];
                scansData = [];
                for (let i = 89; i >= 0; i -= 10) {
                    const date = new Date();
                    date.setDate(date.getDate() - i);
                    days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                    scansData.push(Math.floor(Math.random() * 1000) + 800);
                }
                break;
            default: // 30d
                days = [];
                scansData = [];
                const today = new Date();
                for (let i = 29; i >= 0; i--) {
                    const date = new Date(today);
                    date.setDate(today.getDate() - i);
                    days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                    scansData.push(Math.floor(Math.random() * 800) + 400);
                }
        }
        
        this.state.charts.scansChart.data.labels = days;
        this.state.charts.scansChart.data.datasets[0].data = scansData;
        this.state.charts.scansChart.update();
    }

    // Providers Section
    loadProvidersData() {
        this.renderProvidersTable();
    }

    renderProvidersTable() {
        const tbody = document.getElementById('providersTableBody');
        if (!tbody) return;
        
        const filteredProviders = this.getFilteredProviders();
        
        if (filteredProviders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="table-loading">No providers found</td></tr>';
            return;
        }

        tbody.innerHTML = filteredProviders.map(provider => `
            <tr>
                <td>
                    <div>
                        <strong>${provider.name}</strong>
                        <br><small style="color: var(--color-text-secondary);">${provider.owner}</small>
                    </div>
                </td>
                <td>${provider.type}</td>
                <td><span class="status-badge status-badge--${provider.status}">${provider.status}</span></td>
                <td>
                    <div class="rating-display">
                        <span class="rating-stars">${provider.rating > 0 ? '★ ' + provider.rating : 'N/A'}</span>
                    </div>
                </td>
                <td>${provider.totalBookings}</td>
                <td>₹${this.formatNumber(provider.revenue)}</td>
                <td>${this.formatDate(provider.joinDate)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn--outline btn--action" onclick="adminApp.viewProvider('${provider.id}')">View</button>
                        ${provider.status === 'pending' ? `<button class="btn btn--primary btn--action" onclick="adminApp.approveProvider('${provider.id}')">Approve</button>` : ''}
                        ${provider.status === 'approved' ? `<button class="btn btn--outline btn--action" onclick="adminApp.suspendProvider('${provider.id}')">Suspend</button>` : ''}
                        ${provider.status === 'suspended' ? `<button class="btn btn--primary btn--action" onclick="adminApp.reactivateProvider('${provider.id}')">Reactivate</button>` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getFilteredProviders() {
        let filtered = [...this.state.providers];
        
        if (this.state.filters.providerStatus) {
            filtered = filtered.filter(p => p.status === this.state.filters.providerStatus);
        }
        
        if (this.state.filters.providerSearch) {
            const search = this.state.filters.providerSearch.toLowerCase();
            filtered = filtered.filter(p => 
                p.name.toLowerCase().includes(search) ||
                p.owner.toLowerCase().includes(search) ||
                p.type.toLowerCase().includes(search)
            );
        }
        
        return filtered;
    }

    handleProviderSearch(e) {
        this.state.filters.providerSearch = e.target.value;
        this.renderProvidersTable();
    }

    handleProviderFilter(e) {
        this.state.filters.providerStatus = e.target.value;
        this.renderProvidersTable();
    }

    viewProvider(providerId) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (!provider) return;

        const modal = document.getElementById('providerModal');
        const modalTitle = document.getElementById('providerModalTitle');
        const modalBody = document.getElementById('providerModalBody');
        const modalActions = document.getElementById('providerModalActions');

        if (!modal || !modalTitle || !modalBody || !modalActions) return;

        modalTitle.textContent = provider.name;
        
        modalBody.innerHTML = `
            <div class="provider-details-grid">
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Owner Name</div>
                    <div class="provider-detail-value">${provider.owner}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Business Type</div>
                    <div class="provider-detail-value">${provider.type}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Current Status</div>
                    <div class="provider-detail-value">
                        <span class="status-badge status-badge--${provider.status}">${provider.status}</span>
                    </div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Rating</div>
                    <div class="provider-detail-value">${provider.rating > 0 ? '★ ' + provider.rating + ' / 5.0' : 'Not rated yet'}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Total Bookings</div>
                    <div class="provider-detail-value">${provider.totalBookings}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Total Revenue</div>
                    <div class="provider-detail-value">₹${this.formatNumber(provider.revenue)}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Join Date</div>
                    <div class="provider-detail-value">${this.formatDate(provider.joinDate)}</div>
                </div>
                <div class="provider-detail-item">
                    <div class="provider-detail-label">Last Active</div>
                    <div class="provider-detail-value">${this.formatDateTime(provider.lastActive)}</div>
                </div>
            </div>
        `;

        modalActions.innerHTML = `
            ${provider.status === 'pending' ? '<button class="btn btn--primary" onclick="adminApp.approveProvider(\'' + provider.id + '\'); adminApp.closeModals();">Approve Provider</button>' : ''}
            ${provider.status === 'approved' ? '<button class="btn btn--outline" onclick="adminApp.suspendProvider(\'' + provider.id + '\'); adminApp.closeModals();">Suspend Provider</button>' : ''}
            ${provider.status === 'suspended' ? '<button class="btn btn--primary" onclick="adminApp.reactivateProvider(\'' + provider.id + '\'); adminApp.closeModals();">Reactivate Provider</button>' : ''}
            <button class="btn btn--outline" onclick="adminApp.sendProviderNotice('${provider.id}')">Send Notice</button>
        `;

        modal.classList.remove('hidden');
    }

    approveProvider(providerId) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (provider) {
            provider.status = 'approved';
            this.renderProvidersTable();
            this.showNotification('success', 'Provider Approved', `${provider.name} has been approved and can now accept bookings.`);
        }
    }

    suspendProvider(providerId) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (provider) {
            provider.status = 'suspended';
            this.renderProvidersTable();
            this.showNotification('warning', 'Provider Suspended', `${provider.name} has been suspended and cannot accept new bookings.`);
        }
    }

    reactivateProvider(providerId) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (provider) {
            provider.status = 'approved';
            this.renderProvidersTable();
            this.showNotification('success', 'Provider Reactivated', `${provider.name} has been reactivated and can now accept bookings.`);
        }
    }

    // Transactions Section
    loadTransactionsData() {
        this.renderTransactionsTable();
    }

    renderTransactionsTable() {
        const tbody = document.getElementById('transactionsTableBody');
        if (!tbody) return;
        
        const filteredTransactions = this.getFilteredTransactions();
        
        if (filteredTransactions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="table-loading">No transactions found</td></tr>';
            return;
        }

        tbody.innerHTML = filteredTransactions.map(transaction => `
            <tr>
                <td><code>${transaction.id}</code></td>
                <td>${this.formatDateTime(transaction.date)}</td>
                <td>${transaction.providerName}</td>
                <td>₹${transaction.amount}</td>
                <td>₹${transaction.convenienceFee}</td>
                <td>${transaction.method}</td>
                <td><span class="status-badge status-badge--${transaction.status}">${transaction.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn--outline btn--action" onclick="adminApp.viewTransaction('${transaction.id}')">View</button>
                        ${transaction.status === 'failed' ? `<button class="btn btn--primary btn--action" onclick="adminApp.retryTransaction('${transaction.id}')">Retry</button>` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getFilteredTransactions() {
        let filtered = [...this.state.transactions];
        
        if (this.state.filters.transactionStatus) {
            filtered = filtered.filter(t => t.status === this.state.filters.transactionStatus);
        }
        
        if (this.state.filters.transactionDateFrom) {
            const fromDate = new Date(this.state.filters.transactionDateFrom);
            filtered = filtered.filter(t => new Date(t.date) >= fromDate);
        }
        
        if (this.state.filters.transactionDateTo) {
            const toDate = new Date(this.state.filters.transactionDateTo);
            toDate.setHours(23, 59, 59);
            filtered = filtered.filter(t => new Date(t.date) <= toDate);
        }
        
        return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    handleTransactionFilter() {
        const fromEl = document.getElementById('transactionDateFrom');
        const toEl = document.getElementById('transactionDateTo');
        const statusEl = document.getElementById('transactionStatusFilter');
        
        this.state.filters.transactionDateFrom = fromEl ? fromEl.value : '';
        this.state.filters.transactionDateTo = toEl ? toEl.value : '';
        this.state.filters.transactionStatus = statusEl ? statusEl.value : '';
        
        this.renderTransactionsTable();
    }

    viewTransaction(transactionId) {
        const transaction = this.state.transactions.find(t => t.id === transactionId);
        if (!transaction) return;
        
        this.showNotification('info', 'Transaction Details', `Transaction ${transaction.id}: ₹${transaction.amount} - ${transaction.status}`);
    }

    exportTransactions() {
        const transactions = this.getFilteredTransactions();
        const csvContent = [
            'Transaction ID,Date,Provider,Amount,Convenience Fee,Method,Status',
            ...transactions.map(t => `${t.id},${t.date},${t.providerName},${t.amount},${t.convenienceFee},${t.method},${t.status}`)
        ].join('\n');

        this.downloadFile(csvContent, 'transactions-export.csv', 'text/csv');
        this.showNotification('success', 'Export Complete', 'Transaction data exported successfully.');
    }

    // Notifications Section
    loadNotificationsData() {
        this.renderNotificationsTable();
    }

    renderNotificationsTable() {
        const tbody = document.getElementById('notificationsTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = this.state.notifications.map(notification => `
            <tr>
                <td>${this.formatNotificationType(notification.type)}</td>
                <td>${this.formatNotificationChannel(notification.channel)}</td>
                <td>${notification.recipient}</td>
                <td class="text-truncate" style="max-width: 200px;" title="${notification.message}">${notification.message}</td>
                <td><span class="status-badge status-badge--${notification.status === 'delivered' ? 'completed' : notification.status}">${notification.status}</span></td>
                <td>${this.formatDateTime(notification.createdAt)}</td>
            </tr>
        `).join('');
    }

    formatNotificationType(type) {
        const types = {
            'provider_approval': 'Provider Approval',
            'booking_confirmation': 'Booking Confirmation',
            'payment_reminder': 'Payment Reminder',
            'system_maintenance': 'System Maintenance',
            'promotional': 'Promotional'
        };
        return types[type] || type;
    }

    formatNotificationChannel(channel) {
        const channels = {
            'whatsapp': 'WhatsApp',
            'sms': 'SMS',
            'email': 'Email'
        };
        return channels[channel] || channel;
    }

    showSendNotificationModal() {
        const modal = document.getElementById('sendNotificationModal');
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    sendNotification() {
        const form = document.getElementById('sendNotificationForm');
        if (!form) return;
        
        // Simulate sending notification
        this.showLoading('Sending notification...');
        
        setTimeout(() => {
            this.hideLoading();
            this.closeModals();
            this.showNotification('success', 'Notification Sent', 'Platform notification sent successfully to all recipients.');
            
            // Add to notifications list
            const newNotification = {
                id: 'notif_' + Date.now(),
                type: 'announcement',
                recipient: 'all_users',
                channel: 'whatsapp',
                status: 'delivered',
                message: 'Platform notification sent from admin panel',
                createdAt: new Date().toISOString()
            };
            
            this.state.notifications.unshift(newNotification);
            this.renderNotificationsTable();
        }, 2000);
    }

    // Analytics Section
    loadAnalyticsData() {
        setTimeout(() => {
            this.createCategoryChart();
        }, 100);
    }

    createCategoryChart() {
        const ctx = document.getElementById('categoryChart');
        if (!ctx || !window.Chart) return;

        const categories = Object.keys(this.state.analytics.appointmentTrends);
        const counts = categories.map(cat => this.state.analytics.appointmentTrends[cat].count);

        this.state.charts.categoryChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: categories.map(cat => cat.charAt(0).toUpperCase() + cat.slice(1)),
                datasets: [{
                    label: 'Appointments',
                    data: counts,
                    backgroundColor: this.config.chartColors.slice(0, categories.length)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    updateAnalyticsTimeframe(timeframe) {
        this.state.filters.analyticsTimeframe = timeframe;
        // Update analytics charts based on timeframe
        this.showNotification('info', 'Timeframe Updated', `Analytics updated for ${timeframe}`);
    }

    exportAnalytics() {
        const analyticsData = {
            timeframe: this.state.filters.analyticsTimeframe,
            appointmentTrends: this.state.analytics.appointmentTrends,
            customerBehavior: this.state.analytics.customerBehavior,
            demandData: this.state.analytics.demandData,
            exportedAt: new Date().toISOString()
        };

        this.downloadFile(JSON.stringify(analyticsData, null, 2), 'analytics-report.json', 'application/json');
        this.showNotification('success', 'Analytics Exported', 'Analytics report downloaded successfully.');
    }

    // Market Insights Section
    loadInsightsData() {
        setTimeout(() => {
            this.createGeographicChart();
        }, 100);
    }

    createGeographicChart() {
        const ctx = document.getElementById('geographicChart');
        if (!ctx || !window.Chart) return;

        const cities = Object.keys(this.marketInsights.geographicTrends);
        const values = Object.values(this.marketInsights.geographicTrends);

        this.state.charts.geographicChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: cities.map(city => city.charAt(0).toUpperCase() + city.slice(1)),
                datasets: [{
                    data: values,
                    backgroundColor: this.config.chartColors.slice(0, cities.length)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                }
            }
        });
    }

    // Utility Functions
    formatNumber(num) {
        if (num >= 100000) {
            return (num / 100000).toFixed(1) + 'L';
        }
        if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatDateTime(dateString) {
        return new Date(dateString).toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    downloadFile(content, filename, contentType) {
        const blob = new Blob([content], { type: contentType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        URL.revokeObjectURL(url);
    }

    // Modal Management
    closeModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }

    // Loading and Notifications
    showLoading(message = 'Loading...') {
        const overlay = document.getElementById('loadingOverlay');
        const text = document.getElementById('loadingText');
        
        if (text) text.textContent = message;
        if (overlay) overlay.classList.remove('hidden');
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) overlay.classList.add('hidden');
    }

    showNotification(type, title, message) {
        const container = document.getElementById('notificationContainer');
        if (!container) return;

        const notificationId = 'notif_' + Date.now();
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.id = notificationId;

        notification.innerHTML = `
            <div class="notification-icon-container">
                ${this.getNotificationIcon(type)}
            </div>
            <div class="notification-content-text">
                <div class="notification-title">${title}</div>
                <p class="notification-message">${message}</p>
            </div>
            <button class="notification-close" onclick="adminApp.dismissNotification('${notificationId}')">&times;</button>
        `;

        container.appendChild(notification);

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            this.dismissNotification(notificationId);
        }, 5000);
    }

    getNotificationIcon(type) {
        const icons = {
            success: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>',
            error: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
            warning: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
            info: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>'
        };
        return icons[type] || icons.info;
    }

    dismissNotification(notificationId) {
        const notification = document.getElementById(notificationId);
        if (notification) {
            notification.classList.add('notification--dismissing');
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }
    }
}

// Initialize the application
let adminApp;

document.addEventListener('DOMContentLoaded', () => {
    try {
        adminApp = new NooQAdminApp();
        window.adminApp = adminApp; // Make available globally for onclick handlers
        console.log('🎉 Noo-Q Admin Panel loaded successfully!');
    } catch (error) {
        console.error('❌ Failed to initialize admin panel:', error);
        document.body.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; height: 100vh; text-align: center; padding: 20px;">
                <div>
                    <h1 style="color: #c01521; margin-bottom: 16px;">Admin Panel Loading Failed</h1>
                    <p style="color: #626e71; margin-bottom: 24px;">There was an error loading the admin panel. Please refresh the page to try again.</p>
                    <button onclick="window.location.reload()" style="background: #217d8d; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer;">
                        Refresh Page
                    </button>
                </div>
            </div>
        `;
    }
});