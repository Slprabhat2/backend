// Noo-Q Enhanced Customer Panel Application
class NooQCustomerApp {
    constructor() {
        this.state = {
            currentUser: null,
            isAuthenticated: false,
            isGuestMode: false,
            currentScreen: 'welcome',
            currentSection: 'home',
            authMode: 'signup',
            otpData: null,
            selectedProvider: null,
            bookingData: {},
            currentBookingStep: 1,
            loyaltyProgram: {},
            notifications: [],
            providers: [],
            userAppointments: [],
            paymentMethods: [],
            invoices: [],
            qrStream: null,
            scanningActive: false
        };

        console.log('🚀 Starting Noo-Q Customer App initialization...');
        this.loadInitialData();
        this.init();
    }

    loadInitialData() {
        console.log('📊 Loading initial customer data...');
        
        // Sample customer profiles with loyalty tiers
        const sampleCustomers = [
            {
                id: "cust_001",
                name: "Amit Patel",
                phone: "+91 98765 43210",
                email: "amit@example.com",
                loyaltyTier: "Gold",
                loyaltyPoints: 1240,
                totalSpent: 8500,
                joinDate: "2025-06-15",
                avatar: "AP"
            },
            {
                id: "cust_002", 
                name: "Priya Sharma",
                phone: "+91 98765 54321",
                email: "priya@example.com",
                loyaltyTier: "Silver",
                loyaltyPoints: 580,
                totalSpent: 3200,
                joinDate: "2025-08-20",
                avatar: "PS"
            },
            {
                id: "cust_003",
                name: "Rohit Singh",
                phone: "+91 98765 12345", 
                email: "rohit@example.com",
                loyaltyTier: "Bronze",
                loyaltyPoints: 150,
                totalSpent: 900,
                joinDate: "2025-09-10",
                avatar: "RS"
            }
        ];

        // Sample providers for exploration
        const sampleProviders = [
            {
                id: "prov_001",
                name: "Elite Hair Studio",
                type: "Salon",
                address: "Shop 15, MG Road, Mumbai",
                distance: "0.8 km",
                rating: 4.8,
                reviewCount: 127,
                priceRange: "₹300-800",
                services: ["Haircut", "Styling", "Grooming"],
                image: null,
                workingHours: "9:00 AM - 8:00 PM",
                phoneNumber: "+91 98765 11111"
            },
            {
                id: "prov_002",
                name: "HealthFirst Clinic", 
                type: "Healthcare",
                address: "Building A, Sector 12, Mumbai",
                distance: "1.2 km",
                rating: 4.6,
                reviewCount: 89,
                priceRange: "₹500-1500",
                services: ["Consultation", "Checkup", "Vaccination"],
                image: null,
                workingHours: "8:00 AM - 10:00 PM",
                phoneNumber: "+91 98765 22222"
            },
            {
                id: "prov_003",
                name: "FitZone Gym",
                type: "Fitness", 
                address: "2nd Floor, Mall Complex, Mumbai",
                distance: "2.1 km",
                rating: 4.5,
                reviewCount: 156,
                priceRange: "₹200-600",
                services: ["Personal Training", "Group Classes", "Nutrition"],
                image: null,
                workingHours: "6:00 AM - 11:00 PM",
                phoneNumber: "+91 98765 33333"
            },
            {
                id: "prov_004",
                name: "AutoCare Plus",
                type: "Automotive",
                address: "Service Lane, Industrial Area, Mumbai", 
                distance: "3.5 km",
                rating: 4.3,
                reviewCount: 67,
                priceRange: "₹800-3000",
                services: ["Car Wash", "Oil Change", "Inspection"],
                image: null,
                workingHours: "8:00 AM - 7:00 PM",
                phoneNumber: "+91 98765 44444"
            },
            {
                id: "prov_005",
                name: "Glow Beauty Spa",
                type: "Beauty",
                address: "Ground Floor, Star Plaza, Mumbai",
                distance: "1.8 km", 
                rating: 4.7,
                reviewCount: 203,
                priceRange: "₹400-1200",
                services: ["Facial", "Massage", "Beauty Treatment"],
                image: null,
                workingHours: "10:00 AM - 9:00 PM",
                phoneNumber: "+91 98765 55555"
            }
        ];

        // Sample appointments with different statuses
        const sampleAppointments = [
            {
                id: "appt_001",
                providerId: "prov_001",
                providerName: "Elite Hair Studio",
                serviceName: "Haircut & Styling",
                date: "2025-09-27",
                time: "14:00",
                duration: 45,
                amount: 500,
                status: "confirmed",
                paymentStatus: "paid",
                paymentMethod: "UPI",
                bookingDate: "2025-09-25T10:30:00Z",
                reminderSent: false
            },
            {
                id: "appt_002", 
                providerId: "prov_002",
                providerName: "HealthFirst Clinic",
                serviceName: "General Consultation",
                date: "2025-09-28",
                time: "10:30",
                duration: 30,
                amount: 800,
                status: "confirmed",
                paymentStatus: "paid", 
                paymentMethod: "Card",
                bookingDate: "2025-09-24T15:20:00Z",
                reminderSent: false
            },
            {
                id: "appt_003",
                providerId: "prov_001", 
                providerName: "Elite Hair Studio",
                serviceName: "Beard Grooming",
                date: "2025-09-20",
                time: "16:00",
                duration: 20,
                amount: 200,
                status: "completed",
                paymentStatus: "paid",
                paymentMethod: "UPI",
                bookingDate: "2025-09-18T12:00:00Z",
                rating: 5,
                review: "Excellent service! Very professional."
            }
        ];

        // Loyalty program configuration
        const loyaltyProgram = {
            tiers: {
                Bronze: { minPoints: 0, maxPoints: 499, multiplier: 1, benefits: ["Basic rewards"] },
                Silver: { minPoints: 500, maxPoints: 999, multiplier: 1.2, benefits: ["Priority booking", "5% discount"] },
                Gold: { minPoints: 1000, maxPoints: 1999, multiplier: 1.5, benefits: ["Free services", "10% discount", "Express checkout"] },
                Platinum: { minPoints: 2000, maxPoints: 9999, multiplier: 2, benefits: ["VIP treatment", "15% discount", "Personal concierge"] }
            },
            pointsPerRupee: 1,
            redemptionRate: 0.5 // 1 point = ₹0.5
        };

        // Sample notifications
        const sampleNotifications = [
            {
                id: "notif_001",
                title: "Appointment Reminder",
                message: "You have an appointment with Elite Hair Studio tomorrow at 2:00 PM",
                time: "2 hours ago",
                type: "reminder",
                read: false
            },
            {
                id: "notif_002",
                title: "Points Earned",
                message: "You earned 50 points from your recent booking!",
                time: "1 day ago", 
                type: "loyalty",
                read: false
            },
            {
                id: "notif_003",
                title: "New Provider Near You",
                message: "FitZone Gym is now available for booking in your area",
                time: "3 days ago",
                type: "promo",
                read: true
            }
        ];

        // Sample invoices
        const sampleInvoices = [
            {
                id: "inv_001",
                appointmentId: "appt_003",
                providerName: "Elite Hair Studio",
                serviceName: "Beard Grooming", 
                date: "2025-09-20",
                amount: 200,
                tax: 36,
                total: 236,
                paymentMethod: "UPI",
                transactionId: "TXN123456789"
            }
        ];

        // Set state
        this.state.providers = sampleProviders;
        this.state.userAppointments = sampleAppointments;
        this.state.loyaltyProgram = loyaltyProgram;
        this.state.notifications = sampleNotifications;
        this.state.invoices = sampleInvoices;

        // For demo - set Amit Patel as default user for quick testing
        // In production, this would be null and require authentication
        this.state.currentUser = sampleCustomers[0];
        this.state.isAuthenticated = false; // Start with welcome screen

        console.log('✅ Initial customer data loaded:', this.state);
    }

    init() {
        console.log('🔧 Initializing customer app...');
        
        try {
            this.setupEventListeners();
            this.registerServiceWorker();
            this.checkAuthStatus();
            this.updateGreeting();
            console.log('✅ Customer app initialized successfully');
        } catch (error) {
            console.error('❌ Initialization error:', error);
            this.showError('Failed to initialize app. Please refresh the page.');
        }
    }

    showError(message) {
        console.error('🚨 Showing error:', message);
        document.body.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; height: 100vh; text-align: center; padding: 20px; background: var(--color-background);">
                <div>
                    <h1 style="color: var(--color-error); margin-bottom: 16px;">App Error</h1>
                    <p style="color: var(--color-text-secondary); margin-bottom: 24px;">${message}</p>
                    <button onclick="window.location.reload()" style="background: var(--color-primary); color: var(--color-btn-primary-text); border: none; padding: 12px 24px; border-radius: var(--radius-base); cursor: pointer; font-family: var(--font-family-base);">
                        Refresh Page
                    </button>
                </div>
            </div>
        `;
    }

    // PWA Service Worker Registration
    registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            const swCode = `
                const CACHE_NAME = 'noo-q-customer-v1';
                const urlsToCache = [
                    '/',
                    '/style.css',
                    '/app.js'
                ];

                self.addEventListener('install', (event) => {
                    event.waitUntil(
                        caches.open(CACHE_NAME)
                            .then((cache) => cache.addAll(urlsToCache))
                    );
                });

                self.addEventListener('fetch', (event) => {
                    event.respondWith(
                        caches.match(event.request)
                            .then((response) => response || fetch(event.request))
                    );
                });
            `;
            
            const blob = new Blob([swCode], { type: 'application/javascript' });
            const swUrl = URL.createObjectURL(blob);
            
            navigator.serviceWorker.register(swUrl)
                .then(() => console.log('✅ Service Worker registered'))
                .catch(error => console.warn('⚠️ Service Worker registration failed:', error));
        }
    }

    setupEventListeners() {
        console.log('🎯 Setting up event listeners...');
        
        // Welcome screen buttons
        const signupBtn = document.getElementById('signupBtn');
        const loginBtn = document.getElementById('loginBtn'); 
        const guestBookBtn = document.getElementById('guestBookBtn');
        
        if (signupBtn) signupBtn.addEventListener('click', () => this.showAuth('signup'));
        if (loginBtn) loginBtn.addEventListener('click', () => this.showAuth('login'));
        if (guestBookBtn) guestBookBtn.addEventListener('click', () => this.startGuestFlow());

        // Auth screen navigation
        const backToWelcome = document.getElementById('backToWelcome');
        const signupTab = document.getElementById('signupTab');
        const loginTab = document.getElementById('loginTab');
        
        if (backToWelcome) backToWelcome.addEventListener('click', () => this.showScreen('welcome'));
        if (signupTab) signupTab.addEventListener('click', () => this.switchAuthMode('signup'));
        if (loginTab) loginTab.addEventListener('click', () => this.switchAuthMode('login'));

        // Auth forms
        const signupForm = document.getElementById('signupForm');
        const loginForm = document.getElementById('loginForm');
        const otpForm = document.getElementById('otpForm');
        const resendOtp = document.getElementById('resendOtp');
        
        if (signupForm) signupForm.addEventListener('submit', (e) => this.handleSignup(e));
        if (loginForm) loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        if (otpForm) otpForm.addEventListener('submit', (e) => this.handleOtpVerification(e));
        if (resendOtp) resendOtp.addEventListener('click', () => this.resendOtp());

        // OTP input handling
        this.setupOtpInputs();

        // Bottom navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.showSection(section);
            });
        });

        // Header actions
        const scanQrBtn = document.getElementById('scanQrBtn');
        const notificationsBtn = document.getElementById('notificationsBtn');
        
        if (scanQrBtn) scanQrBtn.addEventListener('click', () => this.scanQRCode());
        if (notificationsBtn) notificationsBtn.addEventListener('click', () => this.showNotifications());

        // Modal controls
        this.setupModalControls();

        // Search and filters
        this.setupSearchAndFilters();

        // Profile actions
        const editProfileBtn = document.getElementById('editProfileBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        
        if (editProfileBtn) editProfileBtn.addEventListener('click', () => this.editProfile());
        if (logoutBtn) logoutBtn.addEventListener('click', () => this.logout());

        console.log('✅ All event listeners set up');
    }

    setupOtpInputs() {
        const otpInputs = document.querySelectorAll('.otp-input');
        otpInputs.forEach((input, index) => {
            input.addEventListener('input', (e) => {
                if (e.target.value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            });
            
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
                    otpInputs[index - 1].focus();
                }
            });
        });
    }

    setupModalControls() {
        // QR Scanner modal
        const closeScanner = document.getElementById('closeScanner');
        if (closeScanner) closeScanner.addEventListener('click', () => this.closeQRScanner());

        // Booking modal
        const closeBooking = document.getElementById('closeBooking');
        const prevStep = document.getElementById('prevStep');
        const nextStep = document.getElementById('nextStep');
        
        if (closeBooking) closeBooking.addEventListener('click', () => this.closeBookingModal());
        if (prevStep) prevStep.addEventListener('click', () => this.prevBookingStep());
        if (nextStep) nextStep.addEventListener('click', () => this.nextBookingStep());

        // Notification panel
        const closeNotifications = document.getElementById('closeNotifications');
        if (closeNotifications) closeNotifications.addEventListener('click', () => this.hideNotifications());

        // Booking date input - Fixed date picker functionality
        const bookingDate = document.getElementById('bookingDate');
        if (bookingDate) {
            const today = new Date();
            const minDate = today.toISOString().split('T')[0];
            bookingDate.min = minDate;
            
            // Fix date picker - ensure proper event handling
            bookingDate.addEventListener('change', (e) => {
                console.log('Date selected:', e.target.value);
                this.state.bookingData.selectedDate = e.target.value;
                this.loadTimeSlots();
            });
            
            // Also handle input event for better compatibility
            bookingDate.addEventListener('input', (e) => {
                console.log('Date input:', e.target.value);
                this.state.bookingData.selectedDate = e.target.value;
                this.loadTimeSlots();
            });
        }

        // Modal backdrop clicks
        document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
            backdrop.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    modal.classList.remove('active');
                    if (modal.id === 'qrScannerModal') {
                        this.stopQRScanner();
                    }
                }
            });
        });
    }

    setupSearchAndFilters() {
        const serviceSearch = document.getElementById('serviceSearch');
        const locationBtn = document.getElementById('locationBtn');
        
        if (serviceSearch) {
            serviceSearch.addEventListener('input', () => this.filterProviders());
        }
        
        if (locationBtn) {
            locationBtn.addEventListener('click', () => this.getCurrentLocation());
        }

        // Category tabs
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                this.filterProviders();
            });
        });

        // Appointment filters
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.filterAppointments();
            });
        });
    }

    updateGreeting() {
        const greeting = document.querySelector('.greeting');
        if (!greeting) return;

        const hour = new Date().getHours();
        let greetingText = 'Good morning';
        
        if (hour >= 12 && hour < 17) {
            greetingText = 'Good afternoon';
        } else if (hour >= 17) {
            greetingText = 'Good evening';
        }
        
        greeting.textContent = greetingText;
    }

    // Authentication Flow
    checkAuthStatus() {
        console.log('🔐 Checking authentication status...');
        
        if (this.state.isAuthenticated && this.state.currentUser) {
            console.log('✅ User authenticated, showing dashboard');
            this.showDashboard();
        } else if (this.state.isGuestMode) {
            console.log('👤 Guest mode, showing limited dashboard');
            this.showDashboard();
        } else {
            console.log('❌ No authentication, showing welcome screen');
            this.showScreen('welcome');
        }
    }

    showAuth(mode) {
        this.state.authMode = mode;
        this.switchAuthMode(mode);
        this.showScreen('auth');
    }

    switchAuthMode(mode) {
        console.log(`🔄 Switching to ${mode} mode`);
        
        this.state.authMode = mode;
        
        const authTitle = document.getElementById('authTitle');
        const signupTab = document.getElementById('signupTab');
        const loginTab = document.getElementById('loginTab');
        const signupForm = document.getElementById('signupForm');
        const loginForm = document.getElementById('loginForm');
        const otpForm = document.getElementById('otpForm');
        
        if (authTitle) authTitle.textContent = mode === 'signup' ? 'Sign Up' : 'Login';
        
        if (signupTab && loginTab) {
            signupTab.classList.toggle('active', mode === 'signup');
            loginTab.classList.toggle('active', mode === 'login');
        }
        
        if (signupForm && loginForm && otpForm) {
            signupForm.classList.toggle('hidden', mode !== 'signup');
            loginForm.classList.toggle('hidden', mode !== 'login');
            otpForm.classList.add('hidden');
        }
    }

    handleSignup(e) {
        e.preventDefault();
        console.log('📝 Handling signup...');
        
        const name = document.getElementById('signupName')?.value;
        const phone = document.getElementById('signupPhone')?.value;
        const email = document.getElementById('signupEmail')?.value;
        
        // Simulate OTP sending
        this.state.otpData = {
            phone: phone,
            name: name,
            email: email,
            type: 'signup',
            otp: '123456', // Demo OTP
            expiresAt: Date.now() + 300000 // 5 minutes
        };
        
        this.showOtpForm(phone);
        this.showToast('success', 'OTP Sent', `Verification code sent to ${phone}`);
    }

    handleLogin(e) {
        e.preventDefault();
        console.log('🔐 Handling login...');
        
        const phone = document.getElementById('loginPhone')?.value;
        
        // Check if user exists (demo logic)
        const existingUser = this.state.currentUser?.phone === phone;
        
        this.state.otpData = {
            phone: phone,
            type: 'login',
            otp: '123456', // Demo OTP
            expiresAt: Date.now() + 300000 // 5 minutes
        };
        
        this.showOtpForm(phone);
        this.showToast('success', 'OTP Sent', `Verification code sent to ${phone}`);
    }

    showOtpForm(phone) {
        const signupForm = document.getElementById('signupForm');
        const loginForm = document.getElementById('loginForm');
        const otpForm = document.getElementById('otpForm');
        const sentToNumber = document.getElementById('sentToNumber');
        
        if (signupForm) signupForm.classList.add('hidden');
        if (loginForm) loginForm.classList.add('hidden');
        if (otpForm) otpForm.classList.remove('hidden');
        if (sentToNumber) sentToNumber.textContent = phone;
        
        // Focus first OTP input
        const firstOtpInput = document.querySelector('.otp-input');
        if (firstOtpInput) firstOtpInput.focus();
    }

    handleOtpVerification(e) {
        e.preventDefault();
        console.log('🔑 Handling OTP verification...');
        
        const otpInputs = document.querySelectorAll('.otp-input');
        const enteredOtp = Array.from(otpInputs).map(input => input.value).join('');
        
        if (enteredOtp === this.state.otpData.otp) {
            console.log('✅ OTP verified successfully');
            
            if (this.state.otpData.type === 'signup') {
                // Create new user
                const newUser = {
                    id: "cust_" + Date.now(),
                    name: this.state.otpData.name,
                    phone: this.state.otpData.phone,
                    email: this.state.otpData.email,
                    loyaltyTier: "Bronze",
                    loyaltyPoints: 0,
                    totalSpent: 0,
                    joinDate: new Date().toISOString().split('T')[0],
                    avatar: this.state.otpData.name.split(' ').map(n => n[0]).join('').toUpperCase()
                };
                
                this.state.currentUser = newUser;
                this.showToast('success', 'Welcome!', 'Account created successfully');
            }
            
            this.state.isAuthenticated = true;
            this.showDashboard();
        } else {
            console.log('❌ Invalid OTP');
            this.showToast('error', 'Invalid OTP', 'Please check the code and try again');
        }
    }

    resendOtp() {
        console.log('📤 Resending OTP...');
        this.showToast('info', 'OTP Resent', 'New verification code sent');
    }

    startGuestFlow() {
        console.log('👤 Starting guest flow...');
        this.state.isGuestMode = true;
        this.state.currentUser = {
            name: "Guest User",
            loyaltyTier: "Guest",
            loyaltyPoints: 0,
            avatar: "GU"
        };
        this.showDashboard();
        this.showToast('info', 'Guest Mode', 'Limited features available. Sign up for full access!');
    }

    // Screen and Section Management
    showScreen(screenId) {
        console.log(`🖥️ Showing screen: ${screenId}`);
        
        // Hide all screens
        document.querySelectorAll('.welcome-screen, .auth-screen, .dashboard-screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        // Show target screen
        const targetScreen = document.getElementById(`${screenId}Screen`);
        if (targetScreen) {
            targetScreen.classList.add('active');
            this.state.currentScreen = screenId;
        }
    }

    showDashboard() {
        console.log('🏠 Showing dashboard...');
        this.showScreen('dashboard');
        this.updateUserInfo();
        this.loadDashboardData();
        this.showSection('home');
    }

    showSection(sectionId) {
        console.log(`📑 Showing section: ${sectionId}`);
        
        // Update navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeNavBtn = document.querySelector(`[data-section="${sectionId}"]`);
        if (activeNavBtn) {
            activeNavBtn.classList.add('active');
        }

        // Update sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        const targetSection = document.getElementById(`${sectionId}Section`);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        this.state.currentSection = sectionId;
        
        // Load section-specific data
        this.loadSectionData(sectionId);
    }

    updateUserInfo() {
        if (!this.state.currentUser) return;
        
        const user = this.state.currentUser;
        
        // Update header
        const userAvatar = document.getElementById('userAvatar');
        const userName = document.getElementById('userName');
        
        if (userAvatar) userAvatar.textContent = user.avatar;
        if (userName) userName.textContent = user.name;
        
        // Update profile section
        const profileInitials = document.getElementById('profileInitials');
        const profileName = document.getElementById('profileName');
        const profilePhone = document.getElementById('profilePhone');
        const profileEmail = document.getElementById('profileEmail');
        
        if (profileInitials) profileInitials.textContent = user.avatar;
        if (profileName) profileName.textContent = user.name;
        if (profilePhone) profilePhone.textContent = user.phone || 'Not provided';
        if (profileEmail) profileEmail.textContent = user.email || 'Not provided';
    }

    loadDashboardData() {
        console.log('📊 Loading dashboard data...');
        this.loadLoyaltyCard();
        this.loadUpcomingAppointments();
        this.loadRecommendedServices();
        this.loadNotifications();
    }

    loadSectionData(sectionId) {
        switch (sectionId) {
            case 'explore':
                this.loadProviders();
                break;
            case 'appointments':
                this.loadAppointmentsList();
                break;
            case 'profile':
                this.loadProfileData();
                break;
        }
    }

    // Loyalty Program
    loadLoyaltyCard() {
        if (!this.state.currentUser || this.state.isGuestMode) return;
        
        const user = this.state.currentUser;
        const program = this.state.loyaltyProgram;
        const currentTier = program.tiers[user.loyaltyTier];
        
        if (!currentTier) return;
        
        // Update tier badge
        const tierBadge = document.querySelector('.tier-badge');
        if (tierBadge) {
            tierBadge.textContent = `${user.loyaltyTier} Member`;
            tierBadge.className = `tier-badge tier-${user.loyaltyTier.toLowerCase()}`;
        }
        
        // Update points balance
        const pointsBalance = document.querySelector('.points-balance');
        if (pointsBalance) {
            pointsBalance.textContent = `${user.loyaltyPoints} points`;
        }
        
        // Calculate progress to next tier
        const nextTierName = this.getNextTier(user.loyaltyTier);
        if (nextTierName) {
            const nextTier = program.tiers[nextTierName];
            const pointsToNext = nextTier.minPoints - user.loyaltyPoints;
            const progressPercent = ((user.loyaltyPoints - currentTier.minPoints) / (nextTier.minPoints - currentTier.minPoints)) * 100;
            
            const progressFill = document.querySelector('.progress-fill');
            const progressText = document.querySelector('.progress-text');
            
            if (progressFill) progressFill.style.width = `${Math.max(0, Math.min(100, progressPercent))}%`;
            if (progressText) progressText.textContent = `${pointsToNext} points to ${nextTierName}`;
        }
    }

    getNextTier(currentTier) {
        const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
        const currentIndex = tiers.indexOf(currentTier);
        return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : null;
    }

    // Appointments Management
    loadUpcomingAppointments() {
        const container = document.getElementById('upcomingAppointments');
        if (!container) return;
        
        const upcoming = this.state.userAppointments.filter(apt => 
            apt.status === 'confirmed' && new Date(apt.date) >= new Date()
        ).slice(0, 3);
        
        if (upcoming.length === 0) {
            container.innerHTML = '<div class="empty-state">No upcoming appointments</div>';
            return;
        }
        
        container.innerHTML = upcoming.map(appointment => `
            <div class="appointment-card">
                <div class="appointment-info">
                    <div class="appointment-provider">${appointment.providerName}</div>
                    <div class="appointment-service">${appointment.serviceName}</div>
                    <div class="appointment-datetime">
                        <span class="appointment-date">${this.formatDate(appointment.date)}</span>
                        <span class="appointment-time">${this.formatTime(appointment.time)}</span>
                    </div>
                </div>
                <div class="appointment-actions">
                    <button class="btn btn--outline btn--sm" onclick="app.viewAppointment('${appointment.id}')">
                        View
                    </button>
                </div>
            </div>
        `).join('');
    }

    loadAppointmentsList() {
        const container = document.getElementById('appointmentsList');
        if (!container) return;
        
        const activeFilter = document.querySelector('.filter-btn.active')?.dataset.filter || 'upcoming';
        let appointments = this.state.userAppointments;
        
        // Filter appointments
        switch (activeFilter) {
            case 'upcoming':
                appointments = appointments.filter(apt => 
                    apt.status === 'confirmed' && new Date(apt.date) >= new Date()
                );
                break;
            case 'past':
                appointments = appointments.filter(apt => 
                    apt.status === 'completed' || new Date(apt.date) < new Date()
                );
                break;
            case 'cancelled':
                appointments = appointments.filter(apt => apt.status === 'cancelled');
                break;
        }
        
        if (appointments.length === 0) {
            container.innerHTML = '<div class="empty-state">No appointments found</div>';
            return;
        }
        
        container.innerHTML = appointments.map(appointment => `
            <div class="appointment-card">
                <div class="appointment-info">
                    <div class="appointment-provider">${appointment.providerName}</div>
                    <div class="appointment-service">${appointment.serviceName}</div>
                    <div class="appointment-datetime">
                        <span class="appointment-date">${this.formatDate(appointment.date)}</span>
                        <span class="appointment-time">${this.formatTime(appointment.time)}</span>
                    </div>
                    <div class="appointment-amount">₹${appointment.amount}</div>
                </div>
                <div class="appointment-actions">
                    <button class="btn btn--outline btn--sm" onclick="app.viewAppointment('${appointment.id}')">
                        Details
                    </button>
                    ${appointment.status === 'confirmed' ? `
                        <button class="btn btn--secondary btn--sm" onclick="app.rescheduleAppointment('${appointment.id}')">
                            Reschedule
                        </button>
                    ` : ''}
                    ${appointment.status === 'completed' && !appointment.rating ? `
                        <button class="btn btn--primary btn--sm" onclick="app.rateAppointment('${appointment.id}')">
                            Rate
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    filterAppointments() {
        this.loadAppointmentsList();
    }

    // Provider Discovery
    loadRecommendedServices() {
        const container = document.getElementById('recommendedServices');
        if (!container) return;
        
        // Show recommended providers based on user history
        const recommended = this.state.providers.slice(0, 3);
        
        container.innerHTML = recommended.map(provider => `
            <div class="provider-card" onclick="app.selectProvider('${provider.id}')">
                <div class="provider-header">
                    <div class="provider-info">
                        <h4>${provider.name}</h4>
                        <span class="provider-type">${provider.type}</span>
                    </div>
                    <div class="provider-rating">
                        ⭐ ${provider.rating}
                    </div>
                </div>
                <div class="provider-distance">${provider.distance} away</div>
                <div class="provider-services">
                    ${provider.services.slice(0, 2).map(service => 
                        `<span class="service-tag">${service}</span>`
                    ).join('')}
                </div>
                <div class="provider-actions">
                    <span class="price-range">${provider.priceRange}</span>
                    <button class="btn btn--primary btn--sm" onclick="app.bookProvider('${provider.id}')">
                        Book Now
                    </button>
                </div>
            </div>
        `).join('');
    }

    loadProviders() {
        const container = document.getElementById('providersGrid');
        if (!container) return;
        
        let providers = [...this.state.providers];
        
        // Apply search filter
        const searchTerm = document.getElementById('serviceSearch')?.value.toLowerCase();
        if (searchTerm) {
            providers = providers.filter(provider =>
                provider.name.toLowerCase().includes(searchTerm) ||
                provider.services.some(service => service.toLowerCase().includes(searchTerm))
            );
        }
        
        // Apply category filter
        const activeCategory = document.querySelector('.category-tab.active')?.dataset.category;
        if (activeCategory && activeCategory !== 'all') {
            providers = providers.filter(provider => 
                provider.type.toLowerCase() === activeCategory.toLowerCase()
            );
        }
        
        if (providers.length === 0) {
            container.innerHTML = '<div class="empty-state">No providers found matching your criteria</div>';
            return;
        }
        
        container.innerHTML = providers.map(provider => `
            <div class="provider-card" onclick="app.selectProvider('${provider.id}')">
                <div class="provider-header">
                    <div class="provider-info">
                        <h3>${provider.name}</h3>
                        <span class="provider-type">${provider.type}</span>
                    </div>
                    <div class="provider-rating">
                        ⭐ ${provider.rating} (${provider.reviewCount})
                    </div>
                </div>
                <div class="provider-details">
                    <div class="provider-address">${provider.address}</div>
                    <div class="provider-distance">${provider.distance} • ${provider.workingHours}</div>
                </div>
                <div class="provider-services">
                    ${provider.services.map(service => 
                        `<span class="service-tag">${service}</span>`
                    ).join('')}
                </div>
                <div class="provider-actions">
                    <span class="price-range">${provider.priceRange}</span>
                    <button class="btn btn--primary btn--sm" onclick="app.bookProvider('${provider.id}')">
                        Book Now
                    </button>
                </div>
            </div>
        `).join('');
    }

    filterProviders() {
        this.loadProviders();
    }

    getCurrentLocation() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.showToast('success', 'Location Found', 'Showing providers near you');
                    // In a real app, you would filter providers by distance
                    this.loadProviders();
                },
                (error) => {
                    this.showToast('warning', 'Location Access', 'Please enable location for better results');
                }
            );
        } else {
            this.showToast('warning', 'Location Not Available', 'Your browser doesn\'t support location services');
        }
    }

    // QR Code Scanner
    scanQRCode() {
        console.log('📷 Opening QR scanner...');
        
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            this.showToast('error', 'Camera Not Available', 'Your device doesn\'t support camera access');
            return;
        }
        
        const modal = document.getElementById('qrScannerModal');
        if (modal) {
            modal.classList.add('active');
            this.startQRScanner();
        }
    }

    async startQRScanner() {
        const video = document.getElementById('qrVideo');
        if (!video) return;
        
        try {
            this.state.qrStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment' }
            });
            
            video.srcObject = this.state.qrStream;
            this.state.scanningActive = true;
            
            // Start scanning loop
            this.scanLoop();
            
        } catch (error) {
            console.error('Camera access error:', error);
            this.showToast('error', 'Camera Error', 'Unable to access camera');
            this.closeQRScanner();
        }
    }

    scanLoop() {
        if (!this.state.scanningActive) return;
        
        const video = document.getElementById('qrVideo');
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
            
            if (typeof jsQR !== 'undefined') {
                const code = jsQR(imageData.data, imageData.width, imageData.height);
                if (code) {
                    console.log('QR Code detected:', code.data);
                    this.handleQRCode(code.data);
                    return;
                }
            }
        }
        
        requestAnimationFrame(() => this.scanLoop());
    }

    handleQRCode(qrData) {
        console.log('Processing QR code:', qrData);
        
        // Stop scanning
        this.stopQRScanner();
        this.closeQRScanner();
        
        try {
            // Parse QR code data (assuming it's a booking URL)
            if (qrData.includes('noo-q.app/book/')) {
                const providerSlug = qrData.split('/book/')[1].split('?')[0];
                const urlParams = new URLSearchParams(qrData.split('?')[1] || '');
                const serviceSlug = urlParams.get('service');
                
                // Find provider by name (simplified matching)
                const provider = this.state.providers.find(p => 
                    p.name.toLowerCase().replace(/\s+/g, '-') === providerSlug
                );
                
                if (provider) {
                    this.showToast('success', 'QR Code Scanned', `Opening booking for ${provider.name}`);
                    this.bookProvider(provider.id, serviceSlug);
                } else {
                    this.showToast('error', 'Provider Not Found', 'This provider is not available in your area');
                }
            } else {
                this.showToast('warning', 'Invalid QR Code', 'This QR code is not recognized');
            }
        } catch (error) {
            console.error('QR processing error:', error);
            this.showToast('error', 'QR Error', 'Unable to process QR code');
        }
    }

    stopQRScanner() {
        this.state.scanningActive = false;
        
        if (this.state.qrStream) {
            this.state.qrStream.getTracks().forEach(track => track.stop());
            this.state.qrStream = null;
        }
    }

    closeQRScanner() {
        this.stopQRScanner();
        
        const modal = document.getElementById('qrScannerModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    // Booking Flow
    selectProvider(providerId) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (provider) {
            this.state.selectedProvider = provider;
            this.showProviderDetails(provider);
        }
    }

    showProviderDetails(provider) {
        // For now, directly show booking modal
        this.bookProvider(provider.id);
    }

    bookProvider(providerId, preselectedService = null) {
        const provider = this.state.providers.find(p => p.id === providerId);
        if (!provider) return;
        
        this.state.selectedProvider = provider;
        this.state.bookingData = {
            providerId: providerId,
            preselectedService: preselectedService
        };
        this.state.currentBookingStep = 1;
        
        this.showBookingModal();
        this.loadBookingStep();
    }

    showBookingModal() {
        const modal = document.getElementById('bookingModal');
        if (modal) {
            modal.classList.add('active');
        }
    }

    closeBookingModal() {
        const modal = document.getElementById('bookingModal');
        if (modal) {
            modal.classList.remove('active');
        }
        
        // Reset booking data
        this.state.bookingData = {};
        this.state.currentBookingStep = 1;
    }

    loadBookingStep() {
        // Hide all steps
        document.querySelectorAll('.booking-step').forEach(step => {
            step.classList.remove('active');
        });
        
        // Show current step
        const currentStep = document.querySelector(`[data-step="${this.state.currentBookingStep}"]`);
        if (currentStep) {
            currentStep.classList.add('active');
        }
        
        // Update navigation buttons
        this.updateBookingNavigation();
        
        // Load step content
        switch (this.state.currentBookingStep) {
            case 1:
                this.loadServicesList();
                break;
            case 2:
                this.loadTimeSlots();
                break;
            case 3:
                this.updateBookingSummary();
                break;
        }
    }

    loadServicesList() {
        const container = document.getElementById('servicesList');
        if (!container || !this.state.selectedProvider) return;
        
        // Demo services for the provider
        const services = [
            { id: 'svc_1', name: 'Basic Service', description: 'Standard service offering', duration: 30, price: 300 },
            { id: 'svc_2', name: 'Premium Service', description: 'Enhanced service with extra benefits', duration: 60, price: 600 },
            { id: 'svc_3', name: 'Deluxe Package', description: 'Complete package with all amenities', duration: 90, price: 900 }
        ];
        
        container.innerHTML = services.map(service => `
            <div class="service-option" onclick="app.selectService('${service.id}')">
                <div class="service-option-header">
                    <h5>${service.name}</h5>
                    <span class="service-price">₹${service.price}</span>
                </div>
                <p>${service.description}</p>
                <div class="service-duration">${service.duration} minutes</div>
            </div>
        `).join('');
    }

    selectService(serviceId) {
        // Remove previous selections
        document.querySelectorAll('.service-option').forEach(option => {
            option.classList.remove('selected');
        });
        
        // Add selection to clicked service
        event.target.closest('.service-option').classList.add('selected');
        
        // Store selection
        this.state.bookingData.selectedService = serviceId;
        
        // Find service details
        const services = [
            { id: 'svc_1', name: 'Basic Service', duration: 30, price: 300 },
            { id: 'svc_2', name: 'Premium Service', duration: 60, price: 600 },
            { id: 'svc_3', name: 'Deluxe Package', duration: 90, price: 900 }
        ];
        
        this.state.bookingData.serviceDetails = services.find(s => s.id === serviceId);
    }

    loadTimeSlots() {
        const container = document.getElementById('timeSlots');
        const dateInput = document.getElementById('bookingDate');
        
        if (!container) return;
        
        // Check if date is selected
        if (!this.state.bookingData.selectedDate) {
            container.innerHTML = '<p class="empty-state">Please select a date first</p>';
            return;
        }
        
        // Generate time slots (demo)
        const slots = [
            '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
            '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
            '17:00', '17:30', '18:00', '18:30'
        ];
        
        container.innerHTML = slots.map(time => `
            <button class="time-slot" onclick="app.selectTimeSlot('${time}')">
                ${this.formatTime(time)}
            </button>
        `).join('');
    }

    selectTimeSlot(time) {
        // Remove previous selections
        document.querySelectorAll('.time-slot').forEach(slot => {
            slot.classList.remove('selected');
        });
        
        // Add selection to clicked slot
        event.target.classList.add('selected');
        
        // Store selection
        this.state.bookingData.selectedTime = time;
    }

    updateBookingSummary() {
        const serviceDetails = this.state.bookingData.serviceDetails;
        if (!serviceDetails) return;
        
        const selectedServiceName = document.getElementById('selectedServiceName');
        const selectedDate = document.getElementById('selectedDate');
        const selectedTime = document.getElementById('selectedTime');
        const totalAmount = document.getElementById('totalAmount');
        
        if (selectedServiceName) selectedServiceName.textContent = serviceDetails.name;
        if (selectedDate) selectedDate.textContent = this.formatDate(this.state.bookingData.selectedDate);
        if (selectedTime) selectedTime.textContent = this.formatTime(this.state.bookingData.selectedTime);
        if (totalAmount) totalAmount.textContent = `₹${serviceDetails.price}`;
    }

    updateBookingNavigation() {
        const prevBtn = document.getElementById('prevStep');
        const nextBtn = document.getElementById('nextStep');
        
        if (prevBtn) {
            prevBtn.style.display = this.state.currentBookingStep === 1 ? 'none' : 'block';
        }
        
        if (nextBtn) {
            nextBtn.textContent = this.state.currentBookingStep === 3 ? 'Pay & Book' : 'Next';
        }
    }

    prevBookingStep() {
        if (this.state.currentBookingStep > 1) {
            this.state.currentBookingStep--;
            this.loadBookingStep();
        }
    }

    nextBookingStep() {
        if (this.state.currentBookingStep === 3) {
            this.processBooking();
            return;
        }
        
        // Validate current step
        if (!this.validateBookingStep()) {
            return;
        }
        
        if (this.state.currentBookingStep < 3) {
            this.state.currentBookingStep++;
            this.loadBookingStep();
        }
    }

    validateBookingStep() {
        switch (this.state.currentBookingStep) {
            case 1:
                if (!this.state.bookingData.selectedService) {
                    this.showToast('warning', 'Select Service', 'Please choose a service to continue');
                    return false;
                }
                break;
            case 2:
                if (!this.state.bookingData.selectedDate || !this.state.bookingData.selectedTime) {
                    this.showToast('warning', 'Select Date & Time', 'Please choose your preferred date and time');
                    return false;
                }
                break;
        }
        return true;
    }

    async processBooking() {
        console.log('💳 Processing booking...');
        
        this.showLoading('Processing your booking...');
        
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value;
        
        if (paymentMethod === 'online') {
            // Simulate Razorpay payment
            await this.processOnlinePayment();
        } else {
            // Process as cash payment
            this.confirmBooking('cash');
        }
    }

    async processOnlinePayment() {
        const serviceDetails = this.state.bookingData.serviceDetails;
        
        // Simulate Razorpay integration
        const options = {
            key: 'rzp_test_demo123456789',
            amount: serviceDetails.price * 100,
            currency: 'INR',
            name: 'Noo-Q',
            description: serviceDetails.name,
            handler: (response) => {
                console.log('Payment successful:', response);
                this.confirmBooking('online', response.razorpay_payment_id);
            },
            prefill: {
                name: this.state.currentUser?.name,
                email: this.state.currentUser?.email,
                contact: this.state.currentUser?.phone
            }
        };
        
        // For demo purposes, simulate successful payment
        setTimeout(() => {
            this.confirmBooking('online', 'pay_demo123456789');
        }, 2000);
    }

    confirmBooking(paymentMethod, transactionId = null) {
        const serviceDetails = this.state.bookingData.serviceDetails;
        
        // Create new appointment
        const newAppointment = {
            id: 'appt_' + Date.now(),
            providerId: this.state.bookingData.providerId,
            providerName: this.state.selectedProvider.name,
            serviceName: serviceDetails.name,
            date: this.state.bookingData.selectedDate,
            time: this.state.bookingData.selectedTime,
            duration: serviceDetails.duration,
            amount: serviceDetails.price,
            status: 'confirmed',
            paymentStatus: paymentMethod === 'online' ? 'paid' : 'pending',
            paymentMethod: paymentMethod,
            transactionId: transactionId,
            bookingDate: new Date().toISOString()
        };
        
        // Add to user appointments
        this.state.userAppointments.push(newAppointment);
        
        // Update loyalty points (if authenticated)
        if (this.state.isAuthenticated && !this.state.isGuestMode) {
            const pointsEarned = Math.floor(serviceDetails.price * this.state.loyaltyProgram.pointsPerRupee);
            this.state.currentUser.loyaltyPoints += pointsEarned;
            
            // Check for tier upgrade
            this.checkTierUpgrade();
            
            this.showToast('success', 'Points Earned!', `You earned ${pointsEarned} loyalty points`);
        }
        
        this.hideLoading();
        this.closeBookingModal();
        
        this.showToast('success', 'Booking Confirmed!', 'Your appointment has been scheduled successfully');
        
        // Send notifications
        this.sendBookingNotifications(newAppointment);
        
        // Refresh dashboard
        this.loadDashboardData();
        this.showSection('home');
    }

    checkTierUpgrade() {
        const user = this.state.currentUser;
        const program = this.state.loyaltyProgram;
        
        for (const [tierName, tierData] of Object.entries(program.tiers)) {
            if (user.loyaltyPoints >= tierData.minPoints && user.loyaltyPoints <= tierData.maxPoints) {
                if (tierName !== user.loyaltyTier) {
                    user.loyaltyTier = tierName;
                    this.showToast('success', 'Tier Upgrade!', `Congratulations! You're now a ${tierName} member`);
                }
                break;
            }
        }
    }

    sendBookingNotifications(appointment) {
        // Add to notifications
        const notification = {
            id: 'notif_' + Date.now(),
            title: 'Booking Confirmed',
            message: `Your appointment with ${appointment.providerName} is confirmed for ${this.formatDate(appointment.date)} at ${this.formatTime(appointment.time)}`,
            time: 'Just now',
            type: 'booking',
            read: false
        };
        
        this.state.notifications.unshift(notification);
        this.updateNotificationBadge();
        
        // Simulate WhatsApp/SMS/Email notifications
        console.log('📱 Sending WhatsApp confirmation...');
        console.log('📧 Sending email confirmation...');
        console.log('📨 Sending SMS confirmation...');
    }

    // Quick Actions
    reorderLastService() {
        const lastAppointment = this.state.userAppointments
            .filter(apt => apt.status === 'completed')
            .sort((a, b) => new Date(b.bookingDate) - new Date(a.bookingDate))[0];
        
        if (lastAppointment) {
            this.showToast('info', 'Re-ordering', `Booking ${lastAppointment.serviceName} again...`);
            this.bookProvider(lastAppointment.providerId);
        } else {
            this.showToast('info', 'No Previous Bookings', 'You haven\'t made any bookings yet');
        }
    }

    showEmergencyConsultation() {
        this.showToast('info', 'Emergency Service', 'Connecting you to emergency consultation...');
        
        // Simulate finding emergency providers
        setTimeout(() => {
            const emergencyProvider = this.state.providers.find(p => p.type === 'Healthcare');
            if (emergencyProvider) {
                this.showToast('success', 'Emergency Provider Found', `Connecting to ${emergencyProvider.name}`);
                this.bookProvider(emergencyProvider.id);
            }
        }, 2000);
    }

    // Notifications
    loadNotifications() {
        this.updateNotificationBadge();
    }

    updateNotificationBadge() {
        const badge = document.querySelector('.notification-badge');
        const unreadCount = this.state.notifications.filter(n => !n.read).length;
        
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'block' : 'none';
        }
    }

    showNotifications() {
        const panel = document.getElementById('notificationPanel');
        const container = document.getElementById('notificationsList');
        
        if (!panel || !container) return;
        
        panel.classList.add('active');
        
        if (this.state.notifications.length === 0) {
            container.innerHTML = '<div class="empty-state">No notifications</div>';
            return;
        }
        
        container.innerHTML = this.state.notifications.map(notification => `
            <div class="notification-item ${notification.read ? '' : 'unread'}">
                <div class="notification-title">${notification.title}</div>
                <p class="notification-message">${notification.message}</p>
                <div class="notification-time">${notification.time}</div>
            </div>
        `).join('');
        
        // Mark all as read
        this.state.notifications.forEach(n => n.read = true);
        this.updateNotificationBadge();
    }

    hideNotifications() {
        const panel = document.getElementById('notificationPanel');
        if (panel) {
            panel.classList.remove('active');
        }
    }

    // Profile Management
    loadProfileData() {
        // Already handled in updateUserInfo and loadLoyaltyCard
    }

    editProfile() {
        this.showToast('info', 'Edit Profile', 'Profile editing feature coming soon!');
    }

    // Appointment Actions
    viewAppointment(appointmentId) {
        const appointment = this.state.userAppointments.find(apt => apt.id === appointmentId);
        if (appointment) {
            alert(`Appointment Details:\n\nProvider: ${appointment.providerName}\nService: ${appointment.serviceName}\nDate: ${this.formatDate(appointment.date)}\nTime: ${this.formatTime(appointment.time)}\nAmount: ₹${appointment.amount}\nStatus: ${appointment.status}`);
        }
    }

    rescheduleAppointment(appointmentId) {
        this.showToast('info', 'Reschedule', 'Rescheduling feature coming soon!');
    }

    rateAppointment(appointmentId) {
        const rating = prompt('Rate your experience (1-5 stars):');
        const review = prompt('Write a review (optional):');
        
        if (rating && rating >= 1 && rating <= 5) {
            const appointment = this.state.userAppointments.find(apt => apt.id === appointmentId);
            if (appointment) {
                appointment.rating = parseInt(rating);
                appointment.review = review || '';
                this.showToast('success', 'Thank You!', 'Your rating has been submitted');
                this.loadAppointmentsList();
            }
        }
    }

    // Utility Functions
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatTime(timeString) {
        const [hours, minutes] = timeString.split(':').map(Number);
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours > 12 ? hours - 12 : (hours === 0 ? 12 : hours);
        return `${displayHours}:${minutes.toString().padStart(2, '0')} ${period}`;
    }

    logout() {
        console.log('🚪 Logging out...');
        
        this.state.currentUser = null;
        this.state.isAuthenticated = false;
        this.state.isGuestMode = false;
        this.showScreen('welcome');
        this.showToast('info', 'Logged Out', 'You have been logged out successfully');
    }

    // UI Helpers
    showLoading(message = 'Loading...') {
        const overlay = document.getElementById('loadingOverlay');
        const text = document.getElementById('loadingText');
        
        if (overlay) overlay.classList.add('active');
        if (text) text.textContent = message;
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) overlay.classList.remove('active');
    }

    showToast(type, title, message) {
        console.log(`📢 Toast: ${type} - ${title}: ${message}`);
        
        const container = document.getElementById('toastContainer');
        if (!container) return;
        
        const toastId = 'toast_' + Date.now();
        const toast = document.createElement('div');
        toast.className = `toast toast--${type}`;
        toast.id = toastId;
        
        toast.innerHTML = `
            <div class="toast-icon">
                ${this.getToastIcon(type)}
            </div>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <p class="toast-message">${message}</p>
            </div>
        `;
        
        container.appendChild(toast);
        
        // Trigger animation
        setTimeout(() => toast.classList.add('show'), 100);
        
        // Auto-dismiss after 4 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }, 4000);
    }

    getToastIcon(type) {
        const icons = {
            success: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>',
            error: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
            warning: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
            info: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>'
        };
        return icons[type] || icons.info;
    }
}

// Initialize app when DOM is loaded
let app;

document.addEventListener('DOMContentLoaded', () => {
    console.log('🌟 DOM Content Loaded - Starting customer app initialization...');
    
    try {
        app = new NooQCustomerApp();
        window.app = app; // Make available globally for onclick handlers
        console.log('🎉 Noo-Q Customer App loaded successfully!');
        
        // Show demo information in console
        console.log('%c=== DEMO LOGIN CREDENTIALS ===', 'color: #217d8d; font-weight: bold; font-size: 16px; background: #f0f8ff; padding: 5px;');
        console.log('%cPhone: +91 98765 43210', 'color: #217d8d; font-weight: bold;');
        console.log('%cOTP: 123456', 'color: #217d8d; font-weight: bold;');
        console.log('%cOr continue as Guest to explore features', 'color: #626e71; font-style: italic;');
        console.log('%c===============================', 'color: #217d8d; font-weight: bold; font-size: 16px; background: #f0f8ff; padding: 5px;');
        
    } catch (error) {
        console.error('❌ Failed to initialize customer app:', error);
        
        document.body.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; height: 100vh; text-align: center; padding: 20px; background: var(--color-background);">
                <div style="max-width: 500px;">
                    <h1 style="color: var(--color-error); margin-bottom: 16px; font-family: var(--font-family-base);">App Loading Failed</h1>
                    <p style="color: var(--color-text-secondary); margin-bottom: 24px; font-family: var(--font-family-base);">There was an error loading the customer app. Please refresh the page to try again.</p>
                    <button onclick="window.location.reload()" style="background: var(--color-primary); color: var(--color-btn-primary-text); border: none; padding: 12px 24px; border-radius: var(--radius-base); cursor: pointer; font-family: var(--font-family-base); font-size: var(--font-size-base);">
                        Refresh Page
                    </button>
                    <div style="margin-top: 20px; padding: 15px; background: var(--color-bg-2); border-radius: var(--radius-base); text-align: left;">
                        <h3 style="margin: 0 0 10px 0; color: var(--color-text);">Error Details:</h3>
                        <pre style="margin: 0; font-size: 12px; color: var(--color-text-secondary); overflow-x: auto;">${error.message}</pre>
                    </div>
                </div>
            </div>
        `;
    }
});

// Additional debugging information
window.addEventListener('load', () => {
    console.log('🔍 Window loaded - performing final checks...');
    console.log('App instance:', app);
    console.log('Available screens:', document.querySelectorAll('.welcome-screen, .auth-screen, .dashboard-screen').length);
    console.log('Bottom navigation items:', document.querySelectorAll('.nav-btn').length);
    console.log('Providers loaded:', app?.state?.providers?.length || 0);
});